import javafx.scene.image.Image;

/**
 * Collectable objects that can be picked up by the player for various purposes
 * and benefits. Superclass of Key, Chip, Coin, Clock.
 * @author Allen Biju, William Allen
 * @version 1
 */
public class Collectable {
    private int val = 0;
    private static Image sprite = new Image("baseTextures/Empty.jpg");

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Fetches the value of the collectable.
     * @return The collectable's value.
     */
    public int getVal() {return val; }

}
