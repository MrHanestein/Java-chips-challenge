import javafx.scene.image.Image;

/**
 * A dirt floor tile.
 * Transforms into path when walked on by player (implemented in Main).
 * @author Owain Jones
 * @version 1
 */
public class Dirt extends TileObjects {

    private static Image sprite = new Image("baseTextures/dirt.png");

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
