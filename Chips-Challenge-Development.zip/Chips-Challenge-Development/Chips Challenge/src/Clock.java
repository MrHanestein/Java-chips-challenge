import javafx.scene.image.Image;

/**
 * A clock - a type of collectable that extends the player's time countdown for the
 * level completion.
 * @author Owain Jones, David Anthony
 */
public class Clock extends Collectable{
    private Image sprite;
    private int clockVal;

    /**
     * Constructs a clock with the given score value.
     * @param clockVal The time value of the clock.
     */
    public Clock(int clockVal)
    {
        this.clockVal = clockVal;

        if (clockVal < 1000)
        {
            sprite = new Image("baseTextures/clock_low.png");
        }
        else if (clockVal < 5000)
        {
            sprite = new Image("baseTextures/clock_med.png");
        }
        else
        {
            sprite = new Image("baseTextures/clock_high.png");
        }
    }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Fetches the time value of the clock.
     * @return The value of the clock.
     */
    public int getVal() {return clockVal; }
}
