import javafx.scene.image.Image;

/**
 * Exit tile that signals the end of the level (end game implemented in Main).
 * @author Owain Jones
 * @version 1
 */
public class Exit extends TileObjects {
    private static Image sprite = new Image("baseTextures/exit.png");
    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
