/**
 * Class containing all relevant user data once logged in.
 * @author Jawad Zaman
 * @version 1
 */
public class User {
    private final String name;
    private final int score;

    /**
     * Constructs a user profile.
     * @param name The username of the user.
     * @param score The score of the user.
     */
    public User(String name, int score) {
        this.name = name;
        this.score = score;
    }

    /**
     * Fetches the name of the user.
     * @return The users saved name as a String.
     */
    public String getName() {
        return name;
    }

    /**
     * Fetches the user's score.
     * @return The score achieved by the user in that level.
     */
    public int getScore() {
        return score;
    }
}

