import javafx.scene.image.Image;
/**
 * Trap tile of Chips Challenge game.
 * Traps entities that walk on it until released via button pressed.
 *
 * @author David Anthony, Owain Jones.
 * @version 1
 */
public class Trap extends TileObjects {

    private Image spriteOn = new Image("baseTextures/trap_closed.png");
    private Image spriteOff = new Image("baseTextures/trap_open.png");
    private Image sprite = spriteOn;
    private int signal;
    private boolean isActive;

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Constructs an active trap.
     * @param signal The signal id that ties a trap to a button.
     */
    public Trap(int signal)
    {
        this.signal = signal;
        this.isActive = true;
    }

    /**
     * Changes the active/inactive state of the trap.
     * @param isOn true/false Whether the trap should now be on or off.
     */
    public void alterState(boolean isOn)
    {
        if (isOn)
        {
            sprite = spriteOn;
            isActive = true;
        }
        else
        {
            sprite = spriteOff;
            isActive = false;
        }
    }

    /**
     * Gets the signal (button-trap link) id number.
     * @return The signal id value
     */
    public int getSignal()
    {
        return signal;
    }

    /**
     * Fetches whether the trap is currently active or not.
     * @return true/false Whether the trap is currently active.
     */
    public boolean getState()
    {
        return isActive;
    }
}