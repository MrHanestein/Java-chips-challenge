import javafx.scene.image.Image;

/**
 * Ice floor tile, the existence of which makes the player skid across to the other
 * side of it (implemented in Main).
 * @author Owain Jones
 * @version 1
 */
public class Ice extends TileObjects {
    private static Image sprite = new Image("baseTextures/ice.png");
    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
