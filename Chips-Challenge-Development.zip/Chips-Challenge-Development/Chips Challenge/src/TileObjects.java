import javafx.scene.image.Image;

/**
 * Superclass/collection of the various tiles implemented in the game.
 * @author Owain Jones, Jawad Zaman
 * @version 1
 */
public class TileObjects {

    private static Image sprite = new Image("baseTextures/Empty.jpg");

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
