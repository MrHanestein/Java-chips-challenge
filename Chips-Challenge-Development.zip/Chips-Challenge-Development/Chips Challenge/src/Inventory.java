/**
 * Inventory object holding all the items picked up by the player in the current
 * level.
 * @author Allen Biju, William Allen, Owain Jones
 * @version 1
 */
public class Inventory {
    private int chips = 0;
    private int coins = 0;
    private int key[] = new int[8];

    /**
     * Set the number of chips to a specific value.
     * @param newChip The new number of chips in the inventory.
     */
    public void setChips(int newChip) {
        this.chips = newChip;
    }

    /**
     * Fetches the number of chips currently in the inventory.
     * @return The number of chips currently held.
     */
    public int getChips() {
        return chips;
    }

    /**
     * Adds the specified number of chips to the total.
     * @param chipNo The number of chips to add to the inventory.
     */
    public void addChips(int chipNo) {
        this.chips += chipNo;
    }

    /**
     * Sets the number of coins held to a specific value.
     * @param newCoin The new amount of coins the player is set to be holding.
     */
    public void setCoins(int newCoin) {
        this.coins = newCoin;
    }

    /**
     * Fetches the number of coins currently held by the player.
     * @return The number of coins in the inventory.
     */
    public int getCoins() {
        return coins;
    }

    /**
     * Adds the specified number of coins to the total.
     * @param coinNo The number of coins to add to the inventory.
     */
    public void addCoins(int coinNo) {
        this.coins += coinNo;
    }

    /**
     * Gets a key from a specific position in those held by the player.
     * @param index The index of the key.
     * @return The key at the specified position.
     */
    public int getKey(int index) {
        if (index >= 0 && index < key.length) {
            return key[index];
        } else {
            return -1;
        }
    }

    /**
     * Gets all keys in player's inventory.
     * @return All the keys held.
     */
    public int[] getAllKeys() {
        return key;
    }

    /**
     * Adds a key to the inventory.
     * @param newKey The key to be added.
     */
    public void addKey(int newKey) {
        boolean hasPlaced = false;

        for (int i = 0; i < key.length - 1; i++)
        {
            if (key[i] == 0 && hasPlaced == false)
            {
                key[i] = newKey;
                hasPlaced = true;
            }
        }
    }

    /**
     * Sets the keys held to a given array.
     * @param keys The new keys held.
     */
    public void setAllKeys(int[] keys) {
        this.key = keys;
    }

    /**
     * Checks if the player has a certain key.
     * @param checkKey Key to check for the presence of.
     * @return Whether that key is present in the inventory.
     */
    public boolean hasKey(int checkKey) {
        boolean hasKey = false;

        for (int i = 0; i < key.length - 1; i++)
        {
            if (key[i] == checkKey)
            {
                hasKey = true;
            }
        }

        return hasKey;
    }
}
