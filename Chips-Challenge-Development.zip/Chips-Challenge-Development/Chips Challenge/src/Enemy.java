import java.util.Objects;
/**
 * Superclass of all enemy entities in the game, provides the classes they must all implement.
 * @author Emilija Baraskina
 * @version 1.8.0
 */
public abstract class Enemy extends Actor
{
    protected Direction direction;
    protected int currentX;
    protected int currentY;
    protected String[] crossableTiles; //tiles that enemy can walk on


    /**
     * Algorithm for calculating and executing entity movement.
     */
    protected abstract void move();

    /**
     * Checks if a given tile is valid to walk on for that enemy.
     * @param tile the tile to check.
     * @return true if tile can be moved on, false if not.
     */
    protected boolean tileCrossable(TileObjects tile) {
        boolean crossable = false;

        //compare given tile to items in the crossable tiles list
        for (String x: crossableTiles) {
            if (Objects.equals(x, tile.getClass().getSimpleName())) {

                crossable = true;
            }
        }
        return crossable;
    }

    /**
     * Checks if movement to the given position is valid.
     * @param x The x coordinate to be checked.
     * @param y The y coordinate to be checked.
     * @return Whether x,y is a valid position for the entity.
     */
    protected boolean validMovementSpace(int x, int y) {
        boolean notInGrid = x >= Main.getGridWidth() || x < 0 ||
                y >= Main.getGridHeight() || y < 0;
        boolean notWalkableTile = !tileCrossable(Main.getValueInTileLayer(x,y)) ||
                Main.getValueInActorLayer(x,y) != null;
        if (notInGrid || notWalkableTile) {
            return false;
        }
        else {
            return true;
        }
    }

    /**
     * If possible, spawn the enemy in the relevant place in the array.
     * @param x the x coordinate to spawn in.
     * @param y the y coordinate to spawn in.
     * @throws IllegalArgumentException if given location is invalid.
     */
    public void spawnIn(int x, int y) {
        if (!validMovementSpace(x,y))
        {
            throw new IllegalArgumentException("Invalid spawn tile");
        }
        Main.setValueInActorLayer(x,y,this);
        this.currentX = x;
        this.currentY = y;
    }
}
