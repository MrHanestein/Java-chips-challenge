import javafx.scene.image.Image;

/**
 * A chip - a type of collectable that is used to unlock chip blocks once a set number
 * of them have been collected in the player's inventory.
 * @author Allen Biju, William Allen
 * @version 1
 */
public class Chips extends Collectable{

    private static Image sprite = new Image("baseTextures/Chip.png");
    private int chipsVal;

    /**
     * Constructs a chip.
     * @param chipsVal The value of the chip.
     */
    public Chips(int chipsVal)
    {
        this.chipsVal = chipsVal;
    }

    /**
     * Fetches the value of the chip.
     * @return The value of the chip.
     */
    public int getVal() {return chipsVal; }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        Chips.sprite = sprite;
    }
}
