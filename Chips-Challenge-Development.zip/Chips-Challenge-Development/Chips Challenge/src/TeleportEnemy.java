import MainSubClasses.MathHelper;
import javafx.scene.image.Image;

/**
 * This class represents a teleporting enemy in the game. This class extends the Enemy class
 * and provides unique behavior for teleporting enemies.
 * TeleportEnemy can swap places with other enemies, altering their positions on the game board.
 *
 * @author David Anthony, William Allen, Emilija Baraskina, Allen Biju, Jawad Zaman
 * Megan Prescott, Owain Jones.
 * @version 1
 */
public class TeleportEnemy extends Enemy {

    Image sprite = new Image("baseTextures/TeleportEnemy.png");
    /*
    private int telX;
    private int telY;
    */


    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }


    /**
     * Constructs and spawns in a teleport enemy.
     *
     * @param x Spawn x-coordinate for the TeleportEnemy.
     * @param y Spawn y-coordinate for the TeleportEnemy.
     */
    public TeleportEnemy(int x, int y) {
        this.crossableTiles = new String[]{"Path", "Button", "Trap"};
        super.spawnIn(x, y);
    }

    /*
    /**
     * Determines the new teleport location for the TeleportEnemy.
     * If the current location contains a TeleportEnemy, updates its coordinates.
     *
     * @param x New x-coordinate to teleport to.
     * @param y New y-coordinate to teleport to.
     * @return Always returns 0 (currently acts as a placeholder).
    public int getTeleportLocation(int x, int y) {
        if (Main.getValueInActorLayer(currentX, currentY) instanceof TeleportEnemy) {
            currentX = telX;
            currentY = telY;
        }
        return 0;
    }
    */

    /**
     * Executes the movement for the TeleportEnemy.
     * Teleports the enemy by swapping positions with other enemies on the game board.
     */
    @Override
    protected void move() {
        boolean hasTeleported = false;
        while (!hasTeleported) {
            Enemy targetEnemy = Main.enemies[MathHelper.returnRandom(0, Main.enemies.length - 1)];

            if (!(targetEnemy instanceof TeleportEnemy)) {
                if (targetEnemy != null) {
                    int trgX = currentX;
                    int trgY = currentY;

                    Main.setValueInActorLayer(targetEnemy.currentX, targetEnemy.currentY, this);

                    currentX = targetEnemy.currentX;
                    currentY = targetEnemy.currentY;
                    Main.setValueInActorLayer(targetEnemy.currentX,targetEnemy.currentY,this);

                    targetEnemy.currentX = trgX;
                    targetEnemy.currentY = trgY;

                    Main.setValueInActorLayer(targetEnemy.currentX, targetEnemy.currentY, targetEnemy);
                    hasTeleported = true;
                }
            }
        }
    }
}
