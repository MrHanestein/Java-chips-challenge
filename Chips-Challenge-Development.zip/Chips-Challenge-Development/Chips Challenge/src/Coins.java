import javafx.scene.image.Image;

/**
 * Coin obejct - a collectable item that boosts the player's score in the level.
 * @author Willian Allen
 * @version 1
 */
public class Coins extends Collectable {
    private static Image sprite = new Image("baseTextures/coin.png");
    private int coinVal;

    /**
     * Constructs a coin of the chosen value.
     * @param coinVal The score value of the coin.
     */
    public Coins(int coinVal)
    {
        this.coinVal = coinVal;
    }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

}
