import javafx.scene.image.Image;

/**
 * Block object - a wall like object that can be pushed around by the player.
 * @author Owain Jones, David Anthony
 * @version 1
 */
public class Block extends Actor
{
    private Image sprite = new Image("baseTextures/copper_block.png");
    private boolean sliding = false;
    private int momentumX = 0;
    private int momentumY = 0;
    private boolean allowedToMove = false;

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Constructs a new block object.
     */
    public Block()
    {}

    /**
     * States that the block may execute a move.
     */
    public void allowMove()
    {
        allowedToMove = true;
    }

    /**
     * States that the block may not execute any more movement.
     */
    public void useMove()
    {
        allowedToMove = false;
    }

    /**
     * Checks whether the block may currently execute a move.
     * @return true/false Whether the block can achieve movement.
     */
    public boolean hasMove()
    {
        return allowedToMove;
    }

    /**
     * Checks whether the block is currently on ice.
     * @return True if the block is currently sliding on ice.
     */
    public boolean isSliding ()
    {
        return sliding;
    }

    /**
     * Sets the block as either in the process of sliding or not.
     * @param slide Whether the block is currently sliding.
     */
    public void setSliding (boolean slide)
    {
        sliding = slide;
    }

    /**
     * Sets the horizontal momentum for the block.
     * @param momentum The horizontal momentum value.
     */
    public void setMomentumX (int momentum)
    {
        momentumX = momentum;
    }

    /**
     * Sets the vertical momentum for the block.
     * @param momentum The vertical momentum value.
     */
    public void setMomentumY (int momentum)
    {
        momentumY = momentum;
    }

    /**
     * Gets the horizontal momentum for the block.
     * @return The horizontal momentum value.
     */
    public int getMomentumX ()
    {
        return momentumX;
    }

    /**
     * Gets the vertical momentum for the block.
     * @return The vertical momentum value.
     */
    public int getMomentumY ()
    {
        return momentumY;
    }
}
