import MainSubClasses.MathHelper;
import MainSubClasses.FileReader;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.TextAlignment;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.scene.text.Text;

import java.io.*;
import java.net.URL;
import java.util.ArrayList;

import static java.util.Arrays.copyOfRange;

/**
 * Chips Challenge game as described in the A2 functional specification.
 * Main class that sets up and executes all major functionality.
 * All customisable changes can be made here (eg. speed of enemies).
 * @author Liam O'Reilly, David Anthony, William Allen, Emilija Baraskina, Allen Biju, Jawad Zaman
 * Owain Jones.
 * @version 5.4
 */
public class Main extends Application {
	// The dimensions of the window
	private static final int TICK_RATE = 60;
	private static final int TICK_RATE_COUNTDOWN = 4;
	private static final int WINDOW_WIDTH = 800;
	private static final int WINDOW_HEIGHT = 500;

	// The dimensions of the canvas
	private static final int CANVAS_WIDTH = 600;
	private static final int CANVAS_HEIGHT = 400;
	private static final int INV_CANVAS_WIDTH = 50;
	private static final int INV_CANVAS_HEIGHT = 250;

	// The width and height (in pixels) of each cell that makes up the game.
	private static final int GRID_CELL_WIDTH = 50;
	private static final int GRID_CELL_HEIGHT = 50;
	
	// The width of the grid in number of cells.
	private static int GRID_WIDTH = 30;
	private static int GRID_HEIGHT = 12;

	private int currentLevelPath = 1;
	private static int texturePack = 1;
	private int momentumX = 0;
	private int momentumY = 0;
	private static int time = 6000;
	// The canvas in the GUI. This needs to be a global variable
	// (in this setup) as we need to access it in different methods.
	// We could use FXML to place code in the controller instead.
	private Canvas canvas;
	private Canvas inventoryCanvas;

	//various images and sprites to be used in menus etc.
	private Image playerImage;
	private Image iconImage;
	private Image chipIconImage;
	private Image mainMenuImage;
	private Image youDiedImage;
	private Image pauseMenuImage;
	private Image inventoryImage;
	private Image winScreenImage;
	private Image logInScreenImage;
	private Image loadLogInScreenImage;
	private Image leaderboardBackgroundImage;

	// X and Y coordinate of player on the grid and camera settings.
	private static int playerX = 0;
	private static int playerY = 0;
	private int cameraX = 0;
	private int cameraY = 0;
	private double cameraRound = 2.4;
	private int cameraOffsetX = 5;
	private int cameraOffsetY = 3;

	//enemy speeds and initialising a username
	private static String currentUsername = "";
	private static int mSpeed = 0;

	private static final int MSPEED_PINK_BALL = 5;
	private static final int MSPEED_BUG = 5;
	private static final int MSPEED_FROG = 11;
	private static final int MSPEED_TELEPORT_ENEMY = 120;

	//array of all enemies in the game
	public static Enemy[] enemies = new Enemy[64];

	//set up tiles
	private static final TileObjects tilePath = new Path();
	private static final TileObjects tileDirt = new Dirt();
	private static final TileObjects tileWater = new Water();
	private static final TileObjects tileExit = new Exit();
	private static final TileObjects tileWall = new Wall();
	private static final TileObjects tileIce = new Ice();
	private boolean	playerOnIce = false;
	private boolean	playerTrapped = false;

	private static final String[] LEVEL_PATHS = new String[] {System.getProperty("user.dir") +
			"/Chips Challenge/src/MainSubClasses/" + "LevelOne" + ".txt", System.getProperty("user.dir") +
			"/Chips Challenge/src/MainSubClasses/" + "LevelTwo" + ".txt", System.getProperty("user.dir") +
			"/Chips Challenge/src/MainSubClasses/" + "LevelThree" + ".txt", System.getProperty("user.dir") +
			"/Chips Challenge/src/MainSubClasses/" + "LevelFour" + ".txt"};



	// Timeline which will cause tick method to be called periodically.
	private Timeline tickTimeline;
	private String username;
	private int score;
	private static final EmptyCollectable emptyCollectable = new EmptyCollectable();

	//Create the 3 Layers
	private static final TileObjects[][] tileLayer = new TileObjects[GRID_WIDTH][GRID_HEIGHT];
	private static final Actor[][] actorLayer = new Actor[GRID_WIDTH][GRID_HEIGHT];
	private final Collectable[][] itemLayer = new Collectable[GRID_WIDTH][GRID_HEIGHT];

	//Create players Inventory
	private final Inventory inventory = new Inventory();

	//set up various buttons for the menu
	private Button playButton;
	private Button leaderboardButton;
	private Button respawnButton;
	private Button quitGameButton;
	private Button pauseExitButton;
	private Button pauseResumeButton;
	private Button endGameQuitButton;
	private Button diedExitButton;
	private Button loadButton;
	private Button leaderboardExitButton;
	private Stage primaryStage = new Stage();
	private Stage mainMenuStage = new Stage();
	private Pane root = buildGUI();
	private Scene gameScene = new Scene(root, WINDOW_WIDTH, WINDOW_HEIGHT);
	//filepath of the level
	private static String filePath = System.getProperty("user.dir") + "/Chips Challenge/src/MainSubClasses/LevelOne.txt";
	private static final String[] level = FileReader.loadFile(filePath);
	private static final String[] highscoreData = FileReader.getHighscore(level);

	private int currentLevel = 1;
	/**
	 * Initialise and set up everything for game start and functionality throughout.
	 * @param primaryStage the primary stage for this application, onto which
	 * the application scene can be set.
	 * @throws FileNotFoundException
	 */
	public void start(Stage primaryStage) throws FileNotFoundException {
		// Load images. Note we use png images with a transparent background.
		playerImage = new Image("baseTextures/sbeve.png");
		iconImage = new Image("baseTextures/icon.png");
		youDiedImage = new Image("MenuTextures/youDied.png");
		mainMenuImage = new Image("MenuTextures/mainmenu.png");
		pauseMenuImage = new Image("MenuTextures/pauseMenu.png");
		winScreenImage = new Image("MenuTextures/winScreen.png");
		logInScreenImage = new Image("MenuTextures/logInMenu.png");
		loadLogInScreenImage = new Image("MenuTextures/loadLogInMenu.png");
		leaderboardBackgroundImage = new Image("MenuTextures/leaderboardBackground.png");

		BackgroundImage background = new BackgroundImage(
				mainMenuImage,
				BackgroundRepeat.NO_REPEAT,    // or NO_REPEAT, depending on your preference
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);

		Pane mainMenuPane = new Pane();
		Scene mainMenuScene = new Scene(mainMenuPane, WINDOW_WIDTH, WINDOW_HEIGHT);
		playButton = new Button();
		playButton.setPrefSize(330, 54);
		playButton.setText("Play!");
		playButton.setLayoutX(230);
		playButton.setLayoutY(175);
		playButton.setOpacity(0);

		loadButton = new Button();
		loadButton.setPrefSize(330, 54);
		loadButton.setText("Load!");
		loadButton.setLayoutX(229);
		loadButton.setLayoutY(244);
		loadButton.setOpacity(0);

		leaderboardButton = new Button();
		leaderboardButton.setPrefSize(330, 54);
		leaderboardButton.setText("Leaderboard");
		leaderboardButton.setOpacity(0);
		leaderboardButton.setLayoutX(230);
		leaderboardButton.setLayoutY(305);

		quitGameButton = new Button();
		quitGameButton.setPrefSize(330, 54);
		quitGameButton.setText("Quit");
		quitGameButton.setOpacity(0);
		quitGameButton.setLayoutX(230);
		quitGameButton.setLayoutY(375);

		quitGameButton.setOnAction(e -> {
			mainMenuStage.close();
		});

		TextField usernameField = new TextField();
		Button loginButton = new Button();
		loginButton.setText("Play!");

		usernameField.setPrefWidth(10);
		VBox loginVbox = new VBox();
		loginVbox.getChildren().addAll(usernameField, loginButton);
		loginVbox.setAlignment(Pos.CENTER);
		StackPane loginPane = new StackPane(loginVbox);


		TextField loadUsernameField = new TextField();
		Button loadLogInButton = new Button();
		loadLogInButton.setText("Load!");

		loadUsernameField.setPrefWidth(10);
		VBox loadLoginVbox = new VBox();
		loadLoginVbox.getChildren().addAll(loadUsernameField, loadLogInButton);
		loadLoginVbox.setAlignment(Pos.CENTER);
		StackPane loadLoginPane = new StackPane(loadLoginVbox, loadLogInButton);

		Scene loginScene = new Scene(loginPane, WINDOW_WIDTH, WINDOW_HEIGHT);
		Scene loadLoginScene = new Scene(loadLoginPane, WINDOW_WIDTH, WINDOW_HEIGHT);

		BackgroundImage logInBackground = new BackgroundImage(
				logInScreenImage,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);

		BackgroundImage loadLoginBackground = new BackgroundImage(
				loadLogInScreenImage,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);


		loginPane.setBackground(new Background(logInBackground));
		loadLoginPane.setBackground(new Background(loadLoginBackground));

		loginButton.setOnAction(e -> {
			User currentUser = new User(username, score);
			username = usernameField.getText();
			currentUsername = username;
			System.out.println("Entered username: " + username);
			primaryStage.setScene(gameScene);
		});

		mainMenuPane.getChildren().addAll(playButton, leaderboardButton, loadButton, quitGameButton);
		mainMenuPane.setBackground(new Background(background));
		mainMenuStage.show();

		playButton.setOnAction(e -> {
			primaryStage.show();
			primaryStage.setScene(loginScene);
			mainMenuStage.close();
		});

		TableView<User> tableView = createHighScoreTableView(highscoreData);
		Pane leaderboardPane = new Pane();
		Scene leaderboardScene = new Scene(leaderboardPane, WINDOW_WIDTH, WINDOW_HEIGHT);

		leaderboardExitButton = new Button();
		leaderboardExitButton.setPrefSize(250, 50);
		leaderboardExitButton.setText("Back");
		leaderboardExitButton.setOpacity(1);
		leaderboardExitButton.setLayoutX(0);
		leaderboardExitButton.setLayoutY(400);

		BackgroundImage leaderboardBackground = new BackgroundImage(
				leaderboardBackgroundImage,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);

		leaderboardPane.setBackground(new Background(leaderboardBackground));
		leaderboardPane.getChildren().addAll(tableView, leaderboardExitButton);

		leaderboardExitButton.setOnAction(e -> {
			mainMenuStage.show();
			primaryStage.close();
		});

		leaderboardButton.setOnAction(e -> {
			primaryStage.show();
			primaryStage.setScene(leaderboardScene);
			mainMenuStage.close();
		});

		loadButton.setOnAction(e -> {
			primaryStage.show();
			primaryStage.setScene(loadLoginScene);
			mainMenuStage.close();
		});

		loadLogInButton.setOnAction(e -> {
			username = loadUsernameField.getText();
			File f = new File(System.getProperty("user.dir") + "/Chips Challenge/src/MainSubClasses/" + username +".txt");
			if(f.exists()) {
				clearLayers();
				inventory.setChips(0);
				inventory.setCoins(0);
				inventory.setAllKeys(new int[8]);
				buildLevel(true);
				drawGame();
				primaryStage.setScene(gameScene);
				primaryStage.show();
				tickTimeline.play();
			}
			else {
				System.out.println("no load file exists");
			}

		});

		// Register an event handler for key presses.
		// This causes the processKeyEvent method to be called each time a key is pressed.
		gameScene.addEventFilter(KeyEvent.KEY_PRESSED, this::processKeyEvent);
				
		// Register a tick method to be called periodically.
		// Make a new timeline with one keyframe that triggers the tick method every half a second.
		tickTimeline = new Timeline(new KeyFrame(Duration.millis(TICK_RATE), event -> tick()));
		 // Loop the timeline forever
		tickTimeline.setCycleCount(Animation.INDEFINITE);
		// We start the timeline upon a button press.

		buildLevel(false);
		tickTimeline.play();

		// Display the scene on the stage
		drawGame();
		mainMenuStage.setScene(mainMenuScene);
		mainMenuStage.show();
	}

	/**
	 * Turns the highscore data for the level into a table.
	 * @param highscoreData The highscore values to be processed.
	 * @return The table representation of the data.
	 */
	private TableView<User> createHighScoreTableView(String[] highscoreData) {
		TableView<User> tableView = new TableView<>();

		// Create columns for name and score
		TableColumn<User, String> nameColumn = new TableColumn<>("Name");
		TableColumn<User, Integer> scoreColumn = new TableColumn<>("Score");

		// Set the cell value factories
		nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
		scoreColumn.setCellValueFactory(new PropertyValueFactory<>("score"));

		// Populate the table with data
		ObservableList<User> data = FXCollections.observableArrayList();
		for (String line : highscoreData) {
			String[] parts = line.split("###|#+");
			String name = parts[0];
			int score = Integer.parseInt(parts[1]);
			data.add(new User(name, score));
		}

		// Add columns to the table
		tableView.getColumns().addAll(nameColumn, scoreColumn);

		// Set data to the table
		tableView.setItems(data);
		return tableView;
	}

	/**
	 * Adds an enemy to the enemy tracking list.
	 * @param x The x coordinate of the enemy.
	 * @param y The y coordinate of the enemy.
	 * @param enemy The enemy entity to be added.
	 */
	public static void addEnemy(int x,int y, Enemy enemy) {
		boolean hasDone = false;
		for (int i = 0; i < enemies.length; i++){
			if (!hasDone) {
				if (enemies[i] == null) {
					enemies[i] = enemy;
					hasDone = true;
				}
			}
		}

	}

	/**
	 * Assembles all the data of the level so it can be launched.
	 * @param resume True if the loading is of a save file, false if a fresh level.
	 */
	private void buildLevel(boolean resume)
	{
		String trgPath = filePath;
		if (resume)
		{
			trgPath = System.getProperty("user.dir") + "/Chips Challenge/src/MainSubClasses/" + username + ".txt";
		}
		//FileReader
		String[] level = FileReader.loadFile(trgPath);
		//FileReader
		int[] baseData = FileReader.getBaseLevel(level);
		String[] highscores = FileReader.getHighscore(level);
		String[] tileLayer = FileReader.getTileLayer(level, baseData[1]);
		String[] itemLayer = FileReader.getItemLayer(level, baseData[1]);
		String[] actorLayer = FileReader.getActorLayer(level, baseData[1]);
		int[] inventoryData = FileReader.getInventory(level, baseData[1]);
		GRID_WIDTH = baseData[0];
		GRID_HEIGHT = baseData[1];
		texturePack = baseData[2];
		time = baseData[3];
		playerX = baseData[4];
		playerY = baseData[5];
		inventory.setChips(inventoryData[0]);
		inventory.setCoins(inventoryData[1]);
		inventory.addKey(inventoryData[2]);
		inventory.addKey(inventoryData[3]);
		inventory.addKey(inventoryData[4]);
		inventory.addKey(inventoryData[5]);
		inventory.addKey(inventoryData[6]);
		inventory.addKey(inventoryData[7]);
		inventory.addKey(inventoryData[8]);
		inventory.addKey(inventoryData[9]);
		fillTileLayer(tilePath);
		fillItemLayer(emptyCollectable);
		for(int y = 0; y < GRID_HEIGHT; y++)
		{
			String[] tiles = tileLayer[y].split("#");
			String[] items = itemLayer[y].split("#");
			String[] actors = actorLayer[y].split("#");
			for(int x = 0; x < GRID_WIDTH; x++)
			{
				levelLoadTiles(x,y,tiles);
				levelLoadItems(x,y,items);
				levelLoadActors(x,y,actors);
			}
		}
		setTexturePack();
		//tickTimeline.play();
		updateInventory();
	}

	/**
	 * Loads tiles into the level from the given data.
	 * @param x The x coordinate of that tile.
	 * @param y The y coordinate of that tile.
	 * @param tiles The array of tiles represented as in their file format.
	 */
	private void levelLoadTiles(int x, int y, String tiles[])
	{
		TileObjects setTile = tilePath;
		int extraData = 0;
		if (tiles[x].length() > 4) {
			extraData = Integer.valueOf(tiles[x].substring(2,5));
		}
		else if (tiles[x].length() > 3) {
			extraData = Integer.valueOf(tiles[x].substring(2,4));
		}
		else if (tiles[x].length() > 2) {
			extraData = Integer.valueOf(tiles[x].substring(2,3));
		}

		switch(tiles[x].substring(0,2))
		{
			case ("WL"):
				setTile = tileWall;
				break;
			case ("PA"):
				setTile = tilePath;
				break;
			case ("DI"):
				setTile = tileDirt;
				break;
			case ("WR"):
				setTile = tileWater;
				break;
			case ("EX"):
				setTile = tileExit;
				break;
			case ("IC"):
				setTile = tileIce;
				break;
			case ("CI"):
				setTile = new CurvedIce(extraData);
				break;
			case ("CL"):
				setTile = new ChipLock(extraData);
				break;
			case ("KB"):
				setTile = new LockedTile(extraData);
				break;
			case ("TR"):
				setTile = new Trap(extraData);
				break;
			case ("BT"):
				setTile = new Lever(extraData);
				break;

		}

		setValueInTileLayer(x,y,setTile);
	}

	/**
	 * Loads collectables into the level from the given data.
	 * @param x The x coordinate of that item.
	 * @param y The y coordinate of that item.
	 * @param items The array of items represented as in their file format.
	 */
	private void levelLoadItems(int x, int y, String items[])
	{
		Collectable setCollectable = emptyCollectable;
		int extraData = 0;
		if (items[x].length() > 6) {
			extraData = Integer.valueOf(items[x].substring(2,7));
		}
		else if (items[x].length() > 5) {
			extraData = Integer.valueOf(items[x].substring(2,6));
		}
		else if (items[x].length() > 4) {
			extraData = Integer.valueOf(items[x].substring(2,5));
		}
		else if (items[x].length() > 3) {
			extraData = Integer.valueOf(items[x].substring(2,4));
		}
		else if (items[x].length() > 2) {
			extraData = Integer.valueOf(items[x].substring(2,3));
		}

		switch(items[x].substring(0,2))
		{
			case("CH"):
				setCollectable = new Chips(extraData);
				break;
			case("CO"):
				setCollectable = new Coins(extraData);
				break;
			case("KY"):
				setCollectable = new Keys(extraData);
				break;
			case("CL"):
				setCollectable = new Clock(extraData);
				break;

		}

		setValueInItemLayer(x,y,setCollectable);
	}

	/**
	 * Loads actor entities into the level from the given data.
	 * @param x The x coordinate of that actor.
	 * @param y The y coordinate of that actor.
	 * @param actors The array of actors in their file format.
	 */
	private void levelLoadActors(int x, int y, String actors[])
	{
		Enemy setActor = null;
		int extraData = 0;
		boolean extraDataSecond = false;
		boolean shouldAdd = true;

		if (actors[x].length() > 3) {
			extraData = Integer.valueOf(actors[x].substring(2,3));
			if ((actors[x].substring(3,4)) == "L") {
				extraDataSecond = true;
			}
		} else if (actors[x].length() > 2) {
			extraData = Integer.valueOf(actors[x].substring(2,3));
		}


		switch(actors[x].substring(0,2))
		{
			case("PB"):
				setActor = new PinkBall(x,y,fromIntToDirection(extraData));
				break;
			case("BG"):
				setActor = new Bug(x,y,fromIntToDirection(extraData),extraDataSecond);
				break;
			case("TE"):
				setActor = new TeleportEnemy(x,y);
				break;
			case("FR"):
				setActor = new Frog(x,y);
				break;
			case("MB"):
				setValueInActorLayer(x,y,new Block());
				shouldAdd = false;
				break;
		}
		if (shouldAdd) {
			addEnemy(x, y, setActor);
		}
	}

	/**
	 * Saves the current state of the level for that user
	 */
	public void saveGame() {
		String saveFile[] = new String[512];
		int saveFileLine = 2;
		saveFile[0] = FileReader.turnBaseData(GRID_WIDTH, GRID_HEIGHT, texturePack, time, playerX, playerY);
		saveFile[1] = "#####";
		for (int i = 0; i < highscoreData.length; i++) {
			saveFile[saveFileLine] = highscoreData[i];
			saveFileLine++;
		}
		saveFile[saveFileLine] = "#####";
		saveFileLine++;

		for (int i = 0; i < GRID_HEIGHT*4 + 4; i++)
		{
			saveFile[saveFileLine + i] = "#####";
		}

		for (int y = 0; y < GRID_HEIGHT; y++) {
			String saveTile = "";
			String saveItem = "";
			String saveActor = "";
			for (int x = 0; x < GRID_WIDTH; x++) {
				saveTile += levelSaveTiles(x, y) + "#";
				saveItem += levelSaveItems(x, y) + "#";
				saveActor += levelSaveActors(x, y) + "#";
			}
			saveFile[13 + y] = saveTile;
			saveFile[13 + 1 + GRID_HEIGHT + y] = saveItem;
			saveFile[13 + 2 + GRID_HEIGHT*2 + y] = saveActor;
		}

		saveFile[13 + 3 + GRID_HEIGHT*3 + 0] = String.valueOf(inventory.getChips())
		 + "#" + String.valueOf(inventory.getCoins())
		 + "#" + String.valueOf(inventory.getKey(0))
		 + "#" + String.valueOf(inventory.getKey(1))
		 + "#" + String.valueOf(inventory.getKey(2))
		 + "#" + String.valueOf(inventory.getKey(3))
		 + "#" + String.valueOf(inventory.getKey(4))
		 + "#" +  String.valueOf(inventory.getKey(5))
		 + "#" + String.valueOf(inventory.getKey(6))
		 + "#" + String.valueOf(inventory.getKey(7));

		FileReader.saveFile(saveFile, System.getProperty("user.dir") + "/Chips Challenge/src/MainSubClasses/" + currentUsername + ".txt");
	}

	/**
	 * Converts tiles to their file format representations.
	 * @param x The x coordinate of the tile in the tile array.
	 * @param y The y coordinate of the tile in the tile array.
	 * @return The tile's representation in the file format.
	 */
	private String levelSaveTiles(int x, int y)
	{
		String retrunVal = "";
		TileObjects trg = getValueInTileLayer(x,y);
		if (getValueInTileLayer(x, y) == null) {
			return  retrunVal;
		} else if (getValueInTileLayer(x, y).equals(tileWall)) {
			retrunVal = "WL";
		} else if (getValueInTileLayer(x, y).equals(tilePath)) {
			retrunVal = "PA";
		} else if (getValueInTileLayer(x, y).equals(tileDirt)) {
			retrunVal = "DI";
		} else if (getValueInTileLayer(x, y).equals(tileWater)) {
			retrunVal = "WR";
		} else if (getValueInTileLayer(x, y).equals(tileExit)) {
			retrunVal = "EX";
		} else if (getValueInTileLayer(x, y).equals(tileIce)) {
			retrunVal = "IC";
		} else if (trg instanceof CurvedIce) {
			retrunVal = "CI" + Integer.toString(((CurvedIce) trg).getRotation());
		} else if (trg instanceof ChipLock) {
			retrunVal = "CL" + Integer.toString(((ChipLock) trg).getCost());
		} else if (trg instanceof LockedTile) {
			retrunVal = "KB" + Integer.toString(((LockedTile) trg).getColour());
		} else if (trg instanceof Trap) {
			retrunVal = "TR" + Integer.toString(((Trap) trg).getSignal());
		} else if (trg instanceof Lever) {
			retrunVal = "BT" + Integer.toString(((Lever) trg).getSignal());
		}
		return retrunVal;
	}

	/**
	 * Converts items to their file format representations.
	 * @param x The x coordinate of the tile in the item array.
	 * @param y The y coordinate of the tile in the item array.
	 * @return The item's representation in the file format.
	 */
	private String levelSaveItems(int x, int y)
	{
		String retrunVal = "EM";
		Collectable trg = getValueInItemLayer(x,y);

		if (getValueInItemLayer(x, y) == null) {
			return  retrunVal;
		} else if (trg instanceof Chips) {
			retrunVal = "CH" + Integer.toString(((Chips) trg).getVal());
		} else if (trg instanceof Coins) {
			retrunVal = "CO" + Integer.toString(((Coins) trg).getVal());
		} else if (trg instanceof Keys) {
			retrunVal = "KY" + Integer.toString(((Keys) trg).getColour());
		} else if (trg instanceof Clock) {
			retrunVal = "CL" + Integer.toString(((Clock) trg).getVal());
		}

		return retrunVal;
	}

	/**
	 * Converts actors to their file format representations.
	 * @param x The x coordinate of the tile in the actor array.
	 * @param y The y coordinate of the tile in the actor array.
	 * @return The actor's representation in the file format.
	 */
	private String levelSaveActors(int x, int y)
	{
		String retrunVal = "EM";
		Actor trg = getValueInActorLayer(x,y);

		if (getValueInActorLayer(x, y) == null) {
			return  retrunVal;
		} else if (trg instanceof PinkBall) {
			retrunVal = "PB" + Integer.toString(fromDirectionToInt(((PinkBall) trg).getDirection()));
		} else if (trg instanceof Bug) {
			retrunVal = "BG" + Integer.toString(fromDirectionToInt(((Bug) trg).getDirection())) +
					isHuggingLeftToString(((Bug) trg).getIsHuggingLeft());
		} else if (trg instanceof TeleportEnemy) {
			retrunVal = "TE";
		} else if (trg instanceof Frog) {
			retrunVal = "FR";
		} else if (trg instanceof Block) {
			retrunVal = "MB";
		}

		return retrunVal;

	}

	/**
	 * Converts whether a bug is sticking to the left or right into the file format representation.
	 * @param isHuggingLeft True if the bug is sticking to the wall on the left.
	 * @return Which side the bug is sticking to in the file format.
	 */
	private static String isHuggingLeftToString(boolean isHuggingLeft) {
		if (isHuggingLeft)
		{
			return "L";
		}
		return "R";
	}

	/**
	 * Converts an int to the respective enumerated Direction.
	 * @param num The number to convert.
	 * @return The corresponding Direction.
	 */
	public static Direction fromIntToDirection(int num) {
		switch(num)
		{
			case(0):
				return Direction.NORTH;
			case(1):
				return Direction.SOUTH;
			case(2):
				return Direction.EAST;
			case(3):
				return Direction.WEST;
		}
		return Direction.NORTH;
	}
	/**
	 * Converts an enumerated Direction to number format.
	 * @param dir The Direction to convert.
	 * @return The corresponding integer.
	 */
	public static int fromDirectionToInt (Direction dir) {
		if (dir == Direction.NORTH)
			return 0;
		else if (dir == Direction.SOUTH)
			return 1;
		else if (dir == Direction.EAST)
			return 2;
		else if (dir == Direction.WEST)
			return 3;

		return 0;
	}

	/**
	 * Process a key event due to a key being pressed, e.g., to move the player.
	 * @param event The key that was pressed.
	 */
	public void processKeyEvent(KeyEvent event) {
		if (!playerOnIce && !playerTrapped) {
			// We change the behaviour depending on the actual key that was pressed.
			switch (event.getCode()) {
				case D, RIGHT ->
						// Right key was pressed. So move the player right by one cell.
						momentumX = 1;
				case A, LEFT ->
						// Right key was pressed. So move the player right by one cell.
						momentumX = -1;
				case S, DOWN ->
						// Right key was pressed. So move the player right by one cell.
						momentumY = 1;
				case W, UP ->
						// Right key was pressed. So move the player right by one cell.
						momentumY = -1;
				case E -> showPauseScreen(mainMenuStage);
				case P -> saveGame();
				default -> {
				}
				// Do nothing for all other keys.
			}
				if (getValueInTileLayer(playerX + momentumX, playerY + momentumY) instanceof ChipLock chipLock) {
					int requiredChips = chipLock.getCost();

					// Check if player has enough chips
					if (inventory.getChips() < requiredChips) {
						// Player does not have enough chips, prevent moving
						// You can add any additional actions or leave this block empty
						momentumX = 0;
						momentumY = 0;
				}
			}
		}
		// Redraw game as the player may have moved.
		drawGame();
		
		// Consume the event. This means we mark it as dealt with. This stops other GUI nodes (buttons etc) responding to it.
		event.consume();
	}

	/**
	 * Assures that the Player remains in the boundaries of the grid.
	 */
	private void enforceBoundaries()
	{
		if (playerX > GRID_WIDTH - 1) {
			playerX = GRID_WIDTH - 1;
		}
		if (playerY > GRID_HEIGHT - 1) {
			playerY = GRID_HEIGHT - 1;
		}
		if (playerX < 0) {
			playerX = 0;
		}
		if (playerY < 0) {
			playerY = 0;
		}
	}

	/**
	 * Makes sure the player cannot move diagonally.
	 */
	private void diagonalRemoval()
	{
		if (momentumX != 0 && momentumY != 0)
		{
			momentumY = 0;
		}
	}

	/**
	 * Sets the texture pack of the game to that set in Main.
	 */
	private void setTexturePack()
	{
		switch(texturePack)
		{
			case(1):
				tileDirt.setSprite(new Image("texturePack1/warped_nylium.png"));
				tileWall.setSprite(new Image("texturePack1/nether_bricks.png"));
				tilePath.setSprite(new Image("texturePack1/netherrack.png"));
				tileWater.setSprite(new Image("texturePack1/lava.gif"));
				tileExit.setSprite(new Image("texturePack1/netherportal.gif"));
				PinkBall.setSprites(new Image("texturePack1/hogling_north.gif"),new Image("texturePack1/hoglin_south.gif"),
						new Image("texturePack1/hogling_west.gif"),new Image("texturePack1/hogling_east.gif"));
				break;
			case(2):
				tileDirt.setSprite(new Image("texturePack2/spruce_leaves.png"));
				tileWall.setSprite(new Image("texturePack2/spruce_log_top.png"));
				tilePath.setSprite(new Image("texturePack2/snow.png"));
				tileExit.setSprite(new Image("texturePack2/spruce_trapdoor.png"));
				PinkBall.setSprites(new Image("texturePack1/hogling_north.gif"),new Image("texturePack1/hoglin_south.gif"),
						new Image("texturePack1/hogling_west.gif"),new Image("texturePack1/hogling_east.gif"));

				break;
			case(3):
				tileDirt.setSprite(new Image("texturePack3/cracked_stone_bricks.png"));
				tileWall.setSprite(new Image("texturePack3/wall.jpg"));
				tilePath.setSprite(new Image("texturePack3/wall_back.jpg"));
				tileExit.setSprite(new Image("texturePack3/end_portal_frame_top.png"));
				break;
			case(4):
				tileDirt.setSprite(new Image("baseTextures/dirt.png"));
				tileWall.setSprite(new Image("baseTextures/wall.jpg"));
				tilePath.setSprite(new Image("baseTextures/path.png"));
				tileWater.setSprite(new Image("baseTextures/water.gif"));
				tileExit.setSprite(new Image("baseTextures/exit.png"));
				break;
		}
	}

	/**
	 * Fills the tile layer with a given tile.
	 * @param tile The tile to fill the layer with.
	 */
	private void fillTileLayer(TileObjects tile)
	{

		for(int i = 0; i < GRID_WIDTH; i++)
		{
			for (int j = 0; j < GRID_HEIGHT; j++)
			{
				tileLayer[i][j] = tile;
			}
		}
	}

	/**
	 * Fills the item layer with a given item.
	 * @param item The item to fill the layer with.
	 */
	private void fillItemLayer(Collectable item)
	{
		for(int i = 0; i < GRID_WIDTH; i++)
		{
			for (int j = 0; j < GRID_HEIGHT; j++)
			{
				itemLayer[i][j] = item;
			}
		}
	}

	/**
	 * Fills the actor layer with a given actor.
	 * @param a The actor to fill the layer with.
	 */
	private void fillActorLayer(Actor a)
	{
		for(int i = 0; i < GRID_WIDTH; i++)
		{
			for (int j = 0; j < GRID_HEIGHT; j++)
			{
				actorLayer[i][j] = a;
			}
		}
	}

	/**
	 * Fetches the game grid height.
	 * @return The grid height.
	 */
	public static int getGridHeight()
	{
		return GRID_HEIGHT;
	}

	/**
	 * Fetches the game grid width.
	 * @return The grid width.
	 */
	public static int getGridWidth()
	{
		return GRID_WIDTH;
	}

	/**
	 * Fetch the current x position of the player.
	 * @return The x coordinate.
	 */
	public static int getPlayerX()
	{
		return playerX;
	}

	/**
	 * Fetch the current y position of the player.
	 * @return The y coordinate.
	 */
	public static int getPlayerY()
	{
		return playerY;
	}

	/**
	 * A simple method to set a single value within the tile layer.
	 * Comes with built-in Checks to avoid Bad Data.
	 * @param x the x coordinate of the value to be changed in the layer.
	 * @param y the y coordinate of the value to be changed in the layer.
	 */
	private void setValueInTileLayer(int x, int y, TileObjects num)
	{
		if (x < GRID_WIDTH  && y < GRID_HEIGHT && x > -1 && y > -1) {

			tileLayer[x][y] = num;
		}

	}

	/**
	 * A simple method to get a value from the tile layer.
	 * @param x the x coordinate in the layer to get.
	 * @param y the y coordinate in the layer to get.
	 * @return The tile at that position.
	 */
	public static TileObjects getValueInTileLayer(int x, int y)
	{
		if (x < GRID_WIDTH && y < GRID_HEIGHT  && x > -1 && y > -1) {

			return tileLayer[x][y];

		}
		return tileWall;
	}

	/**
	 * A simple method to set a single value within the item layer.
	 * Comes with built-in Checks to avoid Bad Data.
	 * @param x the x coordinate of the value to be changed in the layer.
	 * @param y the y coordinate of the value to be changed in the layer.
	 */
	private void setValueInItemLayer(int x, int y, Collectable num)
	{
		if (x < GRID_WIDTH && y < GRID_HEIGHT && x > -1 && y > -1) {

			itemLayer[x][y] = num;
		}
	}

	/**
	 * A simple method to get a value from the item layer.
	 * @param x the x coordinate in the layer to get.
	 * @param y the y coordinate in the layer to get.
	 * @return The item at that position.
	 */
	private Collectable getValueInItemLayer(int x, int y)
	{
		if (x < GRID_WIDTH && y < GRID_HEIGHT && x > -1 && y > -1) {

			return itemLayer[x][y];

		}
		return emptyCollectable;
	}

	/**
	 * A simple method to set a single value within the actor layer.
	 * Comes with built-in Checks to avoid Bad Data.
	 * @param x the x coordinate of the value to be changed in the layer.
	 * @param y the y coordinate of the value to be changed in the layer.
	 */
	public static void setValueInActorLayer(int x, int y, Actor actor)
	{
		if (x < GRID_WIDTH && y < GRID_HEIGHT && x > -1 && y > -1) {

			actorLayer[x][y] = actor;
		}
	}

	/**
	 * A simple method to get a value from the actor layer.
	 * @param x the x coordinate in the layer to get.
	 * @param y the y coordinate in the layer to get.
	 * @return The actor entity at that position.
	 */
	public static Actor getValueInActorLayer(int x, int y)
	{
		if (x < GRID_WIDTH && y < GRID_HEIGHT && x > -1 && y > -1) {

			return actorLayer[x][y];

		}
		return null;
	}

	/**
	 * Add collectable image to inventory when picked up
	 */
	private void updateInventory() {
		GraphicsContext gc = inventoryCanvas.getGraphicsContext2D();
		//inventoryImage = new Image("baseTextures/inventory.png");

		int yOffset = 0;
		for(int i = 0; i < inventory.getAllKeys().length; i++) {
			int keyNum = inventory.getKey(i);

			if(keyNum > 0) {
				Keys key = new Keys(keyNum);
				Image keySprite = key.getSprite();
				gc.drawImage(keySprite, 0, yOffset);
				yOffset += keySprite.getHeight() + 1;
			}
		}

		int chipYOffset = 200;
		Chips invChip = new Chips(0);
		Image chipImage = invChip.getSprite();
		int chipValue = inventory.getChips();
		if (chipValue == 0) {
			chipValue = 0;
			gc.fillText("x" + chipValue, 0, chipYOffset + chipImage.getHeight() / 2);
		} else if (chipValue > 0) {
			gc.drawImage(chipImage, 0, chipYOffset);
			gc.fillText("x" + chipValue, 0, chipYOffset + chipImage.getHeight() / 2);
		}
	}

	/**
	 * Check if the tile being checked affects the movement/interactions of
	 * that/other entities in the game.
	 * @param x The x coordinate of the position to check.
	 * @param y The y coordinate of the position to check.
	 * @param isPlayer Whether it is the player that is in that position.
	 */
	public void checkTile(int x, int y, boolean isPlayer){
		playerTrapped = false;

		if (getValueInTileLayer(x, y).equals(tileDirt) && isPlayer) {
			setValueInTileLayer(x, y, tilePath);
		} else if (getValueInTileLayer(x, y).equals(tileWater) && isPlayer) {
			showLevelFailedScene();

		} else if (getValueInTileLayer(x, y).equals(tileExit) && isPlayer) {
			currentLevel++;
			clearLayers();
			if (currentLevel == 2) {
				filePath = System.getProperty("user.dir") +  "/Chips Challenge/src/MainSubClasses/LevelTwo.txt"; // Construct file path
				buildLevel(false);
			} else if (currentLevel == 3) {
				filePath = System.getProperty("user.dir") +  "/Chips Challenge/src/MainSubClasses/LevelThree.txt";
				buildLevel(false);
			} else if (currentLevel == 4) {
				filePath = System.getProperty("user.dir") + "/Chips Challenge/src/MainSubClasses/LevelFour.txt";
				buildLevel(false);
			} else if (currentLevel == 5) {
				filePath = System.getProperty("user.dir") +  "/Chips Challenge/src/MainSubClasses/LevelFive.txt";
				buildLevel(false);
			} else if (currentLevel == 6) {
				showGameOverScene();
			}

		} else if (getValueInTileLayer(x, y) instanceof Lever) {
			((Lever) getValueInTileLayer(x, y)).alterState(true);
			int trgSignal = ((Lever) getValueInTileLayer(x, y)).getSignal();

			for(int i = 0; i < GRID_WIDTH - 1; i++) {
				for (int j = 0; j < GRID_HEIGHT - 1; j++) {
					if (tileLayer[i][j] instanceof Trap) {
						if (((Trap) tileLayer[i][j]).getSignal() == trgSignal)
							((Trap) tileLayer[i][j]).alterState(false);
					}
				}
			}
		} else if (getValueInTileLayer(x, y) instanceof Trap && isPlayer) {
			if (((Trap) getValueInTileLayer(x, y)).getState())
			{
				playerTrapped = true;
			}
		}

		if (getValueInItemLayer(x, y) instanceof Coins) {
			inventory.addCoins(1);
			setValueInItemLayer(x, y, emptyCollectable);
		} else if (getValueInItemLayer(x, y) instanceof Chips) {
			inventory.addChips(itemLayer[x][y].getVal());
			setValueInItemLayer(x, y, emptyCollectable);
			updateInventory();
		} else if (getValueInItemLayer(x, y) instanceof Keys) {
			inventory.addKey(((Keys) itemLayer[x][y]).getColour());
			setValueInItemLayer(x, y, emptyCollectable);
			updateInventory();
		}

		else if (getValueInItemLayer(x, y) instanceof Clock) {
			time += ((Clock) itemLayer[x][y]).getVal();
			setValueInItemLayer(x, y, emptyCollectable);
		}

		if (getValueInTileLayer(x, y) instanceof ChipLock chipLock) {
			int requiredChips = chipLock.getCost();

			// Check if player has enough chips
			if (inventory.getChips() >= requiredChips) {
				// Player has enough chips, allow moving and update inventory
				inventory.addChips(-requiredChips); // Deduct chips from inventory
				setValueInTileLayer(x, y, tilePath);
				updateInventory();
			}
		}

		if (getValueInActorLayer(x, y) != null && isPlayer) {
			showLevelFailedScene();
		}

	}

	/**
	 * Displays the level completion screen for successful level completion.
	 */
	public void showGameOverScene(){
		BackgroundImage endingBackground = new BackgroundImage(
				winScreenImage,
				BackgroundRepeat.NO_REPEAT,    // or NO_REPEAT, depending on your preference
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);

		Stage gameOverStage = new Stage();
		Pane gameOverPane = new Pane();
		Scene gameOverScene = new Scene(gameOverPane, WINDOW_WIDTH, WINDOW_HEIGHT);
		gameOverStage.setScene(gameOverScene);
		gameOverPane.setBackground(new Background(endingBackground));
		score = MathHelper.calculateScore(time, inventory.getChips(), inventory.getCoins());
		Text gameOverText = new Text(" " + score);
		gameOverText.setX(360);
		gameOverText.setY(300);
		gameOverText.setFont(Font.font("Verdana", FontWeight.BOLD, 20));

		updateScoreFile();

		gameOverStage.show();
		Stage currentStage = (Stage) canvas.getScene().getWindow();
		currentStage.close();
		tickTimeline.stop();

		endGameQuitButton = new Button();
		endGameQuitButton.setPrefSize(460, 55);
		endGameQuitButton.setLayoutX(180);
		endGameQuitButton.setLayoutY(370);
		endGameQuitButton.setOpacity(0);

		endGameQuitButton.setOnAction(e -> {

			mainMenuStage.show();

			gameOverStage.close();
		});

		gameOverPane.getChildren().addAll(gameOverText, endGameQuitButton);
	}




	/**
	 * Updates the highscores for the level if a new recordable record is reached.
	 */
	private void updateScoreFile()
	{
		//get scores
		String[] names = new String[10];
		int[] scores = new int[10];
		int i = 0;
		for (String line : highscoreData)
		{
			String[] parts = line.split("###|#+");
			names[i] = parts[0];
			scores[i] = Integer.parseInt(parts[1]);
			i++;
		}

		//loop and compare
		boolean foundMatching = false;
		for (int j = 0; j < 10; j++)
		{
			if (!foundMatching && score >= scores[j])
			{
				foundMatching = true;

				for (int k = 9; k > j; k--)
				{
					scores[k] = scores[k - 1];
					names[k] = names[k - 1];
				}
				scores[j] = score;
				names[j] = username;
			}
		}

		//write
		String[] file = FileReader.loadFile(filePath);
		String[] fileTop = copyOfRange(file, 0, 2);
		String[] fileBottom = copyOfRange(file, 12, file.length);
		String[] scoresSection = new String[10];

		for (int j = 0; j < 10; j++)
		{
			String line = names[j] + "###" + scores[j] + "################";
			scoresSection[j] = line;
		}

		try
		{
			File levelFile = new File(filePath);
			FileWriter writer = new FileWriter(levelFile, false);
			BufferedWriter bWriter = new BufferedWriter(writer);
			for (String line : fileTop)
			{
				bWriter.write(line + "\n");
			}
			for (int j = 0; j < 10; j++)
			{
				bWriter.write(scoresSection[j] + "\n");
			}
			for (String line : fileBottom)
			{
				bWriter.write(line + "\n");
			}
			bWriter.close();

		}
		catch (IOException e)
		{
			throw new RuntimeException("uh oh scoring broke");
		}
	}

	/**
	 * Displays a game over screen for when the player fails to complete the level.
	 */
	public void showLevelFailedScene(){

		BackgroundImage background = new BackgroundImage(
				youDiedImage,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);

		Stage levelFailedStage = new Stage();
		Pane levelFailedPane = new Pane();
		Scene levelFailedScene = new Scene(levelFailedPane, WINDOW_WIDTH, WINDOW_HEIGHT);
		levelFailedStage.setScene(levelFailedScene);
		levelFailedPane.setBackground(new Background(background));
		respawnButton = new Button();
		respawnButton.setPrefSize(490, 50);
		respawnButton.setOpacity(0);
		respawnButton.setLayoutX(160);
		respawnButton.setLayoutY(315);

		diedExitButton = new Button();
		diedExitButton.setPrefSize(490, 50);
		diedExitButton.setOpacity(0);
		diedExitButton.setLayoutX(160);
		diedExitButton.setLayoutY(390);

		diedExitButton.setOnAction(e -> {
			clearLayers();
			mainMenuStage.show();
			buildLevel(false);
			tickTimeline.play();
			drawGame();
			levelFailedStage.close();
		});

		levelFailedPane.getChildren().addAll(respawnButton, diedExitButton);

		respawnButton.setOnAction(e -> {
			clearLayers();
			inventory.setChips(0);
			inventory.setCoins(0);
			inventory.setAllKeys(new int[8]);
			buildLevel(false);
			drawGame();
			levelFailedStage.close();
			primaryStage.setScene(gameScene);
			primaryStage.show();
			tickTimeline.play();
			updateInventory();
		});

		levelFailedStage.show();
		Stage currentStage = (Stage) canvas.getScene().getWindow();
		currentStage.close();
		tickTimeline.stop();
	}

	/**
	 * resets all level layers to be empty
	 */
	private void clearLayers() {
		fillTileLayer(null);
		fillItemLayer(null);
		fillActorLayer(null);
	}

	/**
	 * Displays a mid game pause menu screen.
	 * @param mainMenuStage The main menu stage.
	 */
	public void showPauseScreen(Stage mainMenuStage) {

		BackgroundImage background = new BackgroundImage(
				pauseMenuImage,
				BackgroundRepeat.NO_REPEAT,
				BackgroundRepeat.NO_REPEAT,
				BackgroundPosition.DEFAULT,
				BackgroundSize.DEFAULT);

		Stage pauseStage = new Stage();
		Pane pausePane = new Pane();
		Scene pauseScene = new Scene(pausePane, WINDOW_WIDTH, WINDOW_HEIGHT);
		pauseStage.setScene(pauseScene);

		pauseResumeButton = new Button();
		pauseResumeButton.setPrefSize(490, 50);
		pauseResumeButton.setText("Resume");
		pauseResumeButton.setLayoutX(160);
		pauseResumeButton.setLayoutY(205);
		pauseResumeButton.setOpacity(0);

		pauseResumeButton.setOnAction(e -> {
			pauseStage.show();
			pauseStage.setScene(gameScene);
			tickTimeline.play();
		});

		pauseExitButton = new Button();
		pauseExitButton.setPrefSize(490, 50);
		pauseExitButton.setText("Save and exit to main menu");
		pauseExitButton.setLayoutX(160);
		pauseExitButton.setLayoutY(300);
		pauseExitButton.setOpacity(0);

		pausePane.getChildren().addAll(pauseExitButton, pauseResumeButton);
		pausePane.setBackground(new Background(background));

		pauseExitButton.setOnAction(e -> {
			saveGame();
			clearLayers();
			buildLevel(false);
			tickTimeline.play();
			mainMenuStage.show();
			pauseStage.close();
		});

		pauseStage.show();
		Stage currentStage = (Stage) canvas.getScene().getWindow();
		currentStage.close();
		tickTimeline.stop();

	}

	/**
	 * Draw the game on the canvas.
	 */
	public void drawGame() {
		// Get the Graphic Context of the canvas. This is what we draw on.
		GraphicsContext gc = canvas.getGraphicsContext2D();

		// Clear canvas
		gc.clearRect(0, 0, canvas.getWidth(), canvas.getHeight());

		// Set the background to gray.
		gc.setFill(Color.BLACK);
		gc.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());

		// Draw row of dirt images
		// We multiply by the cell width and height to turn a coordinate in our grid into a pixel coordinate.
		// We draw the row at y value 2.


		// Draw Tiles for the Tile Layer
		for(int x = 0; x < GRID_WIDTH; x++) {
			for (int y = 0; y < GRID_HEIGHT; y++) {
				TileObjects tile = tileLayer[x][y];
				if (tile != null) {


					if (tileLayer[x][y] instanceof Lever) {
						gc.drawImage(tilePath.getSprite(), (x - cameraX) * GRID_CELL_WIDTH, (y - cameraY) * GRID_CELL_HEIGHT);

					}

					gc.drawImage(tileLayer[x][y].getSprite(), (x - cameraX) * GRID_CELL_WIDTH, (y - cameraY) * GRID_CELL_HEIGHT);

					if (tileLayer[x][y] instanceof ChipLock) {
						int start = -(((ChipLock) tileLayer[x][y]).getCost() - 1) * 4;


						for (int i = 0; i < ((ChipLock) tileLayer[x][y]).getCost(); i++) {
							gc.drawImage(chipIconImage, (((x - cameraX) * GRID_CELL_WIDTH) + GRID_CELL_WIDTH / 2 - 8) + start + 8 * i, (y - cameraY) * GRID_CELL_HEIGHT);
						}
					}

					if (itemLayer[x][y] != emptyCollectable) {
						gc.drawImage(itemLayer[x][y].getSprite(), (x - cameraX) * GRID_CELL_WIDTH, (y - cameraY) * GRID_CELL_HEIGHT);
					}


					//draw appropriate actor
					if (actorLayer[x][y] != null) {
						gc.drawImage(actorLayer[x][y].getSprite(), (x - cameraX) * GRID_CELL_WIDTH, (y - cameraY) * GRID_CELL_HEIGHT);
					}

				}
			}
		}

		// Draw player at current location
		gc.drawImage(playerImage, (playerX - cameraX) * GRID_CELL_WIDTH, (playerY - cameraY) * GRID_CELL_HEIGHT);

		gc.setFill(Color.WHITE);
		gc.setTextAlign(TextAlignment.LEFT);
		gc.setTextBaseline(VPos.CENTER);
		gc.fillText(MathHelper.tickToTime(time, TICK_RATE), 0, GRID_HEIGHT/2);
	}

	/**
	 * Performs necessary actions on every tick - checks for
	 * and carries out entity interactions, moves player and
	 * enemies.
	 */
	public void tick() {

		for(int x = 0; x < GRID_WIDTH - 1; x++) {
			for (int y = 0; y < GRID_HEIGHT - 1; y++) {
					if (tileLayer[x][y] instanceof Trap) {
						((Trap) tileLayer[x][y]).alterState(true);
					} else if (tileLayer[x][y] instanceof Lever) {
						if (actorLayer[x][y] instanceof Block) {
							((Lever) tileLayer[x][y]).alterState(true);
							checkTile(x, y, false);
						} else {
							((Lever) tileLayer[x][y]).alterState(false);
						}
					}

					if (actorLayer[x][y] instanceof Block) {
						Block trgBlock = ((Block) actorLayer[x][y]);
						if (trgBlock.isSliding() && trgBlock.hasMove()) {
							trgBlock.useMove();

							if (tileLayer[x][y] == tileIce || tileLayer[x][y] instanceof CurvedIce) {
								if (tileLayer[x + trgBlock.getMomentumX()][y + trgBlock.getMomentumY()] instanceof CurvedIce) {
									int newMoments[] = doCurvedIceBlock(x, y, trgBlock.getMomentumX(), trgBlock.getMomentumY());

									setValueInActorLayer(x, y, null);
									int blockX = x + (trgBlock.getMomentumX());
									int blockY = y + (trgBlock.getMomentumY());
									setValueInActorLayer(blockX, blockY, trgBlock);
									trgBlock.setSliding(true);
									trgBlock.setMomentumX(newMoments[0]);
									trgBlock.setMomentumY(newMoments[1]);
								} else {
									int iceModifier = doIceCheckBlock(false, x, y, trgBlock.getMomentumX(), trgBlock.getMomentumY());
									setValueInActorLayer(x, y, null);
									int blockX = x + (trgBlock.getMomentumX() * iceModifier);
									int blockY = y + (trgBlock.getMomentumY() * iceModifier);
									setValueInActorLayer(blockX, blockY, trgBlock);
									trgBlock.setSliding(true);
									trgBlock.setMomentumX(trgBlock.getMomentumX() * iceModifier);
									trgBlock.setMomentumY(trgBlock.getMomentumY() * iceModifier);
								}
							} else {
								trgBlock.setSliding(false);
								trgBlock.setMomentumX(0);
								trgBlock.setMomentumY(0);

							}
						} else if (tileLayer[x][y] == tileWater) {
							tileLayer[x][y] = tilePath;
							setValueInActorLayer(x, y, null);
						}
					}
				}
			}


		diagonalRemoval();

		if (momentumX != 0 || momentumY != 0)
		{

			if (getValueInActorLayer(playerX + momentumX,playerY + momentumY) instanceof Block)
			{
				TileObjects potentialTile = getValueInTileLayer(playerX + (momentumX*2),playerY + (momentumY*2));
				Block block = (Block) getValueInActorLayer(playerX + momentumX,playerY + momentumY);
				int blockX = playerX + momentumX;
				int blockY = playerY + momentumY;
				if (potentialTile != tileWall && !(potentialTile instanceof ChipLock) && !(potentialTile instanceof LockedTile))
				{
					if (potentialTile == tileIce) {
						int iceModifier = doIceCheckBlock(false, blockX, blockY,momentumX,momentumY);
						setValueInActorLayer(blockX, blockY, null);
						blockX = blockX + (momentumX * iceModifier);
						blockY = blockY + (momentumY * iceModifier);
						setValueInActorLayer(blockX, blockY, block);
						block.setSliding(true);
						block.setMomentumX(momentumX * iceModifier);
						block.setMomentumY(momentumY * iceModifier);
					}
					else {
						setValueInActorLayer(blockX, blockY, null);
						blockX = blockX + (momentumX);
						blockY = blockY + (momentumY);
						block.setMomentumX(0);
						block.setMomentumY(0);
						block.setSliding(false);
						setValueInActorLayer(blockX, blockY, block);
					}

					playerMove();
				}
			}
			else {
				playerMove();
			}
		}

		setCamera();

		//Ensure our Player is in the playing field.
		enforceBoundaries();

		// Check what tile the player is on
		checkTile(playerX, playerY, true);

		mSpeed++;
		//trigger enemy movement
		//arraylist used to make sure no actor moves multiple times per tick
		//trigger enemy movement
		//arraylist used to make sure no actor moves multiple times per tick
		ArrayList<Actor> actorsMoved = new ArrayList<Actor>();
		for (int x = 0; x < GRID_WIDTH; x++)
		{
			for (int y = 0; y < GRID_HEIGHT; y++) {
				Actor actor = actorLayer[x][y];
				if (actor != null) {
					boolean isEnemy = actor instanceof Enemy;
					boolean actorNotTrapped = !(tileLayer[x][y] instanceof Trap && ((Trap) tileLayer[x][y]).getState());
					if (!actorsMoved.contains(actor) && isEnemy && actorNotTrapped)
					{
						boolean pBallMoveValid = actor instanceof PinkBall && mSpeed % MSPEED_PINK_BALL == 0;
						boolean bugMoveValid = actor instanceof Bug && mSpeed % MSPEED_BUG == 0;
						boolean frogMoveValid = actor instanceof Frog && mSpeed % MSPEED_FROG == 0;
						boolean teleportMoveValid = actor instanceof TeleportEnemy && mSpeed % MSPEED_TELEPORT_ENEMY == 0;

						if (pBallMoveValid || bugMoveValid || frogMoveValid || teleportMoveValid)
						{
							Enemy enemy = (Enemy) actor;
							enemy.move();
							actorsMoved.add(actor);
						}
					}
					else if (actor instanceof Block)
					{
						((Block) actor).allowMove();
					}
				}
			}
		}

		time -= TICK_RATE_COUNTDOWN;
		// We then redraw the whole canvas.
		drawGame();
	}

	/**
	 * Calculates and carries out player movement according to the keyboard input
	 */
	private void playerMove()
	{
		if (getValueInTileLayer(playerX + momentumX, playerY + momentumY) != tileWall){

			if (getValueInTileLayer(playerX + momentumX, playerY + momentumY) instanceof CurvedIce)
			{
				int playerDir = MathHelper.convertToAngle(momentumX, momentumY);
				int iceDir = ((CurvedIce) getValueInTileLayer(playerX + momentumX, playerY + momentumY)).getRotation();
				IceChecks action = IceChecks.WALL;

				playerDir -= 180;

				if (playerDir < 0)
				{
					playerDir = 360 + playerDir;
				}

				if (playerDir == iceDir)
				{
					action = IceChecks.FROMBASE;
				}
				else if (playerDir == iceDir + 90 || playerDir == iceDir - 270)
				{
					action = IceChecks.FROMNEXT;
				}

				if (action == IceChecks.WALL)
				{
					doIceCheck(true);
				}
				else
				{
					int newPlayerDir = 0;

					if (action == IceChecks.FROMBASE)
					{
						newPlayerDir = iceDir + 90;
					}
					else
					{
						newPlayerDir = iceDir;
					}

					playerX = playerX + momentumX;
					playerY = playerY + momentumY;
					int[] newMomentums = MathHelper.convertFromAngle(newPlayerDir);
					momentumX = newMomentums[0];
					momentumY = newMomentums[1];
					playerOnIce = true;
				}
			} else if (getValueInTileLayer(playerX + momentumX, playerY + momentumY) instanceof LockedTile) {
				int requiredKey = ((LockedTile) getValueInTileLayer(playerX + momentumX, playerY + momentumY)).getColour();

				// Check if player has enough chips
				if (inventory.hasKey(requiredKey)) {

					setValueInTileLayer(playerX + momentumX, playerY + momentumY, tilePath);
				}
				else
				{
					momentumX = 0;
					momentumY = 0;
				}
			}
			else {
				playerX = playerX + momentumX;
				playerY = playerY + momentumY;
				doIceCheck(false);

				// Check if the next cell is a chip lock
				if (getValueInTileLayer(playerX + momentumX, playerY + momentumY) instanceof ChipLock) {
					int requiredChips = ((ChipLock) getValueInTileLayer(playerX + momentumX, playerY + momentumY)).getCost();

					// Check if player has enough chips
					if (inventory.getChips() < requiredChips) {
						// Player does not have enough chips, bounce back
						momentumX = -momentumX;
						momentumY = -momentumY;
					}
				}
			}
		}
		else
		{
			momentumX = 0;
			momentumY = 0;
		}

	}

	/**
	 * Sets the camera settings for the level scrolling
	 */
	private void setCamera()
	{
		cameraX = (playerX - cameraOffsetX);
		cameraY = (playerY - cameraOffsetY);
		if (cameraX < 0)
		{
			cameraX = 0;
		}
		if (cameraX > GRID_WIDTH - (cameraOffsetX*cameraRound))
		{
			cameraX = GRID_WIDTH - (int) Math.ceil(cameraOffsetX*cameraRound);
		}
		if (cameraY < 0)
		{
			cameraY = 0;
		}
		if (cameraY > GRID_HEIGHT - (cameraOffsetY*cameraRound))
		{
			cameraY = GRID_HEIGHT - (int) Math.ceil(cameraOffsetY*cameraRound);
		}
	}

	/**
	 * Checks if the player is currently on ice.
	 * @param assumeWall Whether it should be treated as though the player is hitting a wall.
	 */
	private void doIceCheck(boolean assumeWall)
	{
		if (getValueInTileLayer(playerX, playerY) == tileIce)
		{
			if (getValueInTileLayer(playerX + momentumX, playerY + momentumY) == tileWall || assumeWall)
			{
				momentumX = -momentumX;
				momentumY = -momentumY;
			}
			playerOnIce = true;
		}
		else
		{
			momentumX = 0;
			momentumY = 0;
			playerOnIce = false;
		}
	}

	/**
	 * Checks the blocks interaction with ice.
	 * @param assumeWall Whether it should be treated as though the block is hitting a wall.
	 * @param blockX The x coordinate of the block.
	 * @param blockY The y coordinate of the block.
	 * @param momentX x coordinate of where the block is about to be.
	 * @param momentY y coordinate of where the block is about to be.
	 * @return How the block is dealing with ice movement.
	 */
	private int doIceCheckBlock(boolean assumeWall, int blockX, int blockY, int momentX, int momentY)
	{

			if (getValueInTileLayer(blockX + momentX, blockY + momentY) == tileWall || assumeWall)
			{
				return -1;
			}

		return 1;
	}

	/**
	 * Handle block movement over curved ice blocks.
	 * @param blockX The x coordinate of the block.
	 * @param blockY The y coordinate of the block.
	 * @param momentX x coordinate of where the block is about to be.
	 * @param momentY y coordinate of where the block is about to be.
	 * @return The coordinates of the outcome of the movement in an array.
	 */
	private int[] doCurvedIceBlock(int blockX, int blockY, int momentX, int momentY){
		if (getValueInTileLayer(blockX + momentX, blockY + momentY) instanceof CurvedIce)
		{
			int blockDir = MathHelper.convertToAngle(momentX, momentY);
			int iceDir = ((CurvedIce) getValueInTileLayer(blockX + momentX, blockY + momentY)).getRotation();
			IceChecks action = IceChecks.WALL;

			blockDir -= 180;

			if (blockDir < 0)
			{
				blockDir = 360 + blockDir;
			}

			if (blockDir == iceDir)
			{
				action = IceChecks.FROMBASE;
			}
			else if (blockDir == iceDir + 90 || blockDir == iceDir - 270)
			{
				action = IceChecks.FROMNEXT;
			}

			if (action == IceChecks.WALL)
			{
				doIceCheckBlock(true, blockX,blockY,momentX,momentY);
			}
			else
			{
				int newBlockDir = 0;

				if (action == IceChecks.FROMBASE)
				{
					newBlockDir = iceDir + 90;
				}
				else
				{
					newBlockDir = iceDir;
				}

				int[] newMomentums = MathHelper.convertFromAngle(newBlockDir);
				return newMomentums;
			}
		}
		int[] failed = {0,0};
		return failed;
	}

	/**
	 * Create the GUI.
	 * @return The panel that contains the created GUI.
	 */
	private Pane buildGUI() {
		// Create top-level panel that will hold all GUI nodes.
		BorderPane root = new BorderPane();

		// Create the canvas that we will draw on.
		// We store this as a global variable so other methods can access it.
		canvas = new Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);


		// Create a toolbar with some nice padding and spacing
		HBox toolbar = new HBox();
		toolbar.setSpacing(10);
		toolbar.setPadding(new Insets(10, 10, 10, 10));
		root.setTop(toolbar);

		// Tick Timeline buttons
		Text timer = new Text();
		timer.setText(String.valueOf(time));

		toolbar.getChildren().add(timer);
		// Stop button is disabled by default

		canvas.setLayoutX(INV_CANVAS_WIDTH);
		inventoryCanvas = new Canvas(INV_CANVAS_WIDTH, INV_CANVAS_HEIGHT);
		inventoryCanvas.setLayoutX(0);
		inventoryCanvas.setLayoutY(0);

		GraphicsContext gcInv = inventoryCanvas.getGraphicsContext2D();
		inventoryImage = new Image("baseTextures/inventory.png");
		gcInv.drawImage(inventoryImage, 0, 0, inventoryCanvas.getWidth(), inventoryCanvas.getHeight());

		root.getChildren().addAll(inventoryCanvas, canvas);

		// Finally, return the border pane we built up.
		return root;
	}

	/**
	 * The main method call.
	 */
	public static void main(String[] args) {
		launch(args);
	}
}