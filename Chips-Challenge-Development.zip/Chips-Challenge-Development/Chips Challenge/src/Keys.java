import javafx.scene.image.Image;

/**
 * The coloured key object that is used to unlock the corresponding door.
 * @author William Allen, Owain Jones
 * @version 1
 */
public class Keys extends Collectable{
    private int keyColour = 0;
    private Image sprite = new Image("baseTextures/key_copper.png");

    /**
     * Generates a key object of the corresponding colour.
     * @param keyColour 1-4, A numerical representation of the colour/type of the key.
     */
    public Keys(int keyColour) {
        this.keyColour = keyColour;

        switch(keyColour)
        {
            case(1):
                sprite = new Image("baseTextures/key_copper.png");
                break;
            case(2):
                sprite = new Image("baseTextures/key_gold.png");
                break;
            case(3):
                sprite = new Image("baseTextures/key_diamond.png");
                break;
            case(4):
                sprite = new Image("baseTextures/key_emerald.png");
                break;
        }
    }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Fetches the colour of the key.
     * @return 1-4, A numerical representation of the colour/type of the key.
     */
    public int getColour() {return keyColour; }
}
