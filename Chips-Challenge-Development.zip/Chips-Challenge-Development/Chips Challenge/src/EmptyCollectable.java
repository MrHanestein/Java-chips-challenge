import javafx.scene.image.Image;

/**
 * An empty/null version of a collectable object.
 * Used to fill the collectable layer when no actual collectables are on the tile.
 * @author Allen Biju, Willian Allen
 * @version 1
 */
public class EmptyCollectable extends Collectable {

    private static Image sprite = new Image("baseTextures/dirt.png");

    /**
     * Fetches the type of the collectable.
     * @return Always returns "Empty".
     */
    public String getType() {
        return "Empty";
    }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}