import javafx.scene.image.Image;
/**
 * Bug monster that follows a left/right edge around the map area it is in.
 * Subclass of Enemy.
 * @author Emilija Baraskina, Owain Jones
 * @version 2
 */
public class Bug extends Enemy
{
    private Image sprite = new Image("baseTextures/spider/spider_north.gif");
    private static Image spriteNorth = new Image("baseTextures/spider/spider_north.gif");
    private static  Image spriteSouth = new Image("baseTextures/spider/spider_south.gif");
    private static Image spriteEast = new Image("baseTextures/spider/spider_east.gif");
    private static Image spriteWest = new Image("baseTextures/spider/spider_west.gif");
    boolean isHuggingLeft;
    private int moveAttemptNo;

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Set sprite images for all directions the entity can face.
     * @param north Image to set as the sprite for when facing north.
     * @param south Image to set as the sprite for when facing south.
     * @param west Image to set as the sprite for when facing west.
     * @param east Image to set as the sprite for when facing east.
     */
    public static void setSprites(Image north, Image south, Image west, Image east) {
        spriteNorth = north;
        spriteSouth = south;
        spriteEast = east;
        spriteWest = west;
    }

    /**
     * Constructs and spawns a bug entity.
     * @param x The x coordinate to spawn in.
     * @param y The y coordinate to spawn in.
     * @param direction The direction the ball initially moves in.
     * @param isHuggingLeft True if hugging non-passable blocks to the left, false if to the right.
     */
    public Bug(int x, int y, Direction direction, boolean isHuggingLeft)
    {
        this.direction = direction;
        this.isHuggingLeft = isHuggingLeft;
        this.crossableTiles = new String[]{"Path", "Button", "Trap"};
        currentX = x;
        currentY = y;
        super.spawnIn(x,y);
    }

    /**
     * Execute 1 tile movement of the enemy.
     * Finds next valid tile along the edge it is following and updates actor layer accordingly.
     */
    @Override
    protected void move()
    {
        boolean movingOnCorner = false;

        //calculate where to be moving to
        int potentialX = currentX;
        int potentialY = currentY;

        switch (direction) {
            case NORTH:
                potentialY -= 1;//0 = top
                sprite = spriteNorth;
                break;
            case SOUTH:
                potentialY += 1;
                sprite = spriteSouth;
                break;
            case EAST:
                potentialX += 1;
                sprite = spriteEast;
                break;
            case WEST:
                potentialX -= 1;
                sprite = spriteWest;
                break;
        }

        //movement validity calculations
        boolean movingNextToWall = isNextToWall(potentialX,potentialY,direction);
        boolean movementValid = super.validMovementSpace(potentialX,potentialY);

        //deal with going around a corner
        Direction directionForAroundCorner = direction; //init to direction for compiler
        if (!movingNextToWall) {
            if (isNextToWall(currentX,currentY,direction) && movementValid) {
                movingOnCorner = true;

                if (isHuggingLeft) {
                    directionForAroundCorner = leftDirection(direction);
                }
                else {
                    directionForAroundCorner = rightDirection(direction);
                }
            }
        }

        //execute normal move against wall if able
        if (movementValid && movingNextToWall) {
            Main.setValueInActorLayer(currentX, currentY, null);
            Main.setValueInActorLayer(potentialX, potentialY, this);
            currentX = potentialX;
            currentY = potentialY;
            moveAttemptNo = 1;
        }
        //move around corner if doing so
        else if (movementValid && movingOnCorner)
        {
            Main.setValueInActorLayer(currentX, currentY, null);
            Main.setValueInActorLayer(potentialX, potentialY, this);
            currentX = potentialX;
            currentY = potentialY;
            direction = directionForAroundCorner;
            moveAttemptNo = 1;
        }
        //deal with finding path otherwise
        else {
            moveAttemptNo++;
            //move straight if unable to find other valid path
            if (moveAttemptNo >= 5 && movementValid) {
                Main.setValueInActorLayer(currentX, currentY, null);
                Main.setValueInActorLayer(potentialX, potentialY, this);
                currentX = potentialX;
                currentY = potentialY;
                moveAttemptNo = 1;
            }
            if (moveAttemptNo > 10) {
                moveAttemptNo = 1;
            }
            else
            {
                //try find valid path by turning
                if (isHuggingLeft)
                {
                    direction = rightDirection(direction);
                    this.move();
                }
                else
                {
                    direction = leftDirection(direction);
                    this.move();
                }
            }
        }

    }

    /**
     * Checks whether the bug is still next to a 'wall' on the side that it should be.
     * @param x The x coordinate position.
     * @param y The y coordinate position.
     * @param direction Direction the bug is facing/moving.
     * @return true/false Whether next to wall on the correct side.
     */
    private boolean isNextToWall(int x, int y, Direction direction) {
        //find x y of tile to check using direc and side
        int xToTest = x;
        int yToTest = y;

        if (isHuggingLeft) {
            switch (direction) {
                case NORTH:
                    xToTest -= 1;
                    break;
                case SOUTH:
                    xToTest += 1;
                    break;
                case EAST:
                    yToTest -= 1;//0 is top
                    break;
                case WEST:
                    yToTest += 1;
                    break;
            }
        }
        else {
            switch (direction) {
                case NORTH:
                    xToTest += 1;
                    break;
                case SOUTH:
                    xToTest -= 1;
                    break;
                case EAST:
                    yToTest += 1;//0 is top
                    break;
                case WEST:
                    yToTest -= 1;
                    break;
            }
        }

        //check if that tile is in fact non moveable
        boolean moveable = super.validMovementSpace(xToTest, yToTest);
        return !moveable;
    }

    /**
     * Calculate the direction to the right of that currently facing.
     * @param direction The direction currently facing.
     * @return The direction 90 degrees clockwise.
     */
    protected Direction rightDirection(Direction direction)
    {
        switch (direction)
        {
            case NORTH:
                return Direction.EAST;
            case SOUTH:
                return Direction.WEST;
            case EAST:
                return Direction.SOUTH;
            case WEST:
                return Direction.NORTH;
        }
        return null;
    }

    /**
     * Calculate the direction to the left of that currently facing.
     * @param direction The direction currently facing.
     * @return The direction 270 degrees clockwise.
     */
    protected Direction leftDirection(Direction direction)
    {
        switch (direction)
        {
            case NORTH:
                return Direction.WEST;
            case SOUTH:
                return Direction.EAST;
            case EAST:
                return Direction.NORTH;
            case WEST:
                return Direction.SOUTH;
        }
        return null;
    }

    public Direction getDirection() {
        return direction;
    }
    public boolean getIsHuggingLeft() {
        return isHuggingLeft;
    }
}
