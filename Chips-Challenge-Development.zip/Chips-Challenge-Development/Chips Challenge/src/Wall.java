import javafx.scene.image.Image;

/**
 * Impassable wall tile (implemented in Main).
 * @author Owain Jones
 * @version 1
 */
public class Wall extends TileObjects {
    private static Image sprite = new Image("baseTextures/wall.jpg");

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
