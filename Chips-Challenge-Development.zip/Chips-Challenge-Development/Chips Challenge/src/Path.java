import javafx.scene.image.Image;

/**
 * Path tile - the default floor tile walkable on by everything.
 * @author Owain Jones
 * @version 1
 */
public class Path extends TileObjects {
    private static Image sprite = new Image("baseTextures/path.png");

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
