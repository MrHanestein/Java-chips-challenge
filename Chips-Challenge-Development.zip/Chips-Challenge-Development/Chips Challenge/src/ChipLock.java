import javafx.scene.image.Image;

/**
 * A door/locked tile that is impassable until unlocked by the player on aquiring the
 * necessary number of chips.
 * @author Owain Jones, Allen Biju
 * @version 1
 */
public class ChipLock extends TileObjects {
    private static Image sprite = new Image("baseTextures/chip_lock.png");
    private final int cost;

    /**
     * Constructs a chip lock block.
     * @param cost The number of chips needed to unnlock it.
     */
    public ChipLock(int cost)
    {
        this.cost = cost;
    }

    /**
     * Fetch the number of chips needed to unlock this block.
     * @return The number of chips necessary.
     */
    public int getCost() {return cost;}

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        ChipLock.sprite = sprite;
    }
}
