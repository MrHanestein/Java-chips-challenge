import javafx.scene.image.Image;
/**
 * Monster that bounces back and forth until the player is hit.
 * Pink ball monster entity, subclass of Enemy.
 * @author Emilija Baraskina
 * @version 2
 */

public class PinkBall extends Enemy
{
    private Image sprite = new Image("baseTextures/spider/spider_north.gif");
    private static Image spriteNorth = new Image("baseTextures/spider/spider_north.gif");
    private static  Image spriteSouth = new Image("baseTextures/spider/spider_south.gif");
    private static Image spriteEast = new Image("baseTextures/spider/spider_east.gif");
    private static Image spriteWest = new Image("baseTextures/spider/spider_west.gif");
    private int moveAttemptNo;

    /**
     * Set sprite images for all directions the entity can face.
     * @param north Image to set as the sprite for when facing north.
     * @param south Image to set as the sprite for when facing south.
     * @param west Image to set as the sprite for when facing west.
     * @param east Image to set as the sprite for when facing east.
     */
    public static void setSprites(Image north, Image south, Image west, Image east) {
        spriteNorth = north;
        spriteSouth = south;
        spriteEast = east;
        spriteWest = west;
    }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Constructs and spawns a pink ball entity.
     * @param x The x coordinate to spawn in.
     * @param y The y coordinate to spawn in.
     * @param direction The direction the ball initially moves in.
     */
    public PinkBall(int x, int y, Direction direction)
    {
        this.direction = direction;
        this.crossableTiles = new String[]{"Path", "Button", "Trap"};
        this.moveAttemptNo = 1;
        currentX = x;
        currentY = y;
        super.spawnIn(x,y);
    }

    /**
     * Execute 1 tile movement of the enemy.
     * Finds next valid tile and moves either forward or in reverse if forward
     * movement not possible.
     */
    @Override
    protected void move()
    {
    //make 2 attempts to move per tick, no more
        boolean moveValid = true;

        //calculate where to be moving to
        int potentialX = currentX;
        int potentialY = currentY;

        switch (direction) {
            case NORTH:
                potentialY = currentY - 1;//0 = top
                sprite = spriteNorth;
                break;
            case SOUTH:
                potentialY = currentY + 1;
                sprite = spriteSouth;
                break;
            case EAST:
                potentialX = currentX + 1;
                sprite = spriteEast;
                break;
            case WEST:
                potentialX = currentX - 1;
                sprite = spriteWest;
                break;
        }
        //check within grid and movement is valid
        moveValid = super.validMovementSpace(potentialX, potentialY);

        //execute move or turn around
        if (moveValid) {
            Main.setValueInActorLayer(currentX, currentY, null);
            Main.setValueInActorLayer(potentialX, potentialY, this);
            currentX = potentialX;
            currentY = potentialY;
            moveAttemptNo = 1;
        }
        else
        {
            //update attempt no and retry in opposite direction
            moveAttemptNo++;
            if (moveAttemptNo > 2) {
                moveAttemptNo = 1;
            }
            else
            {
                direction = oppositeDirection(direction);
                move();
            }
        }
    }

    /**
     * Finds opposite direction of a given direction.
     * @param direction The direction currently facing.
     * @return The opposite direction.
     */
    protected Direction oppositeDirection(Direction direction)
    {
        switch (direction)
        {
            case NORTH:
                return Direction.SOUTH;
            case SOUTH:
                return Direction.NORTH;
            case EAST:
                return Direction.WEST;
            case WEST:
                return Direction.EAST;
        }
        return null;
    }
    public Direction getDirection() {
        return direction;
    }
}
