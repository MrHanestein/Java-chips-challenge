import javafx.scene.image.Image;

import java.util.ArrayList;
import java.util.Random;

/**
 * Frog monster that chases the player along the shortest path possible, moving
 * randomly if unable to access the player.
 * Subclass of Enemy.
 * @author Emilija Baraskina, Owain Jones
 * @version 2
 */
public class Frog extends Enemy
{
    private Image sprite = new Image("baseTextures/frog.png");
    private static final int PATHFINDER_UNWALKABLE_VAL = -1;
    private final int pathfinderPlayerVal;
    private int[][] pathfindingGrid;

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Constructs and spawns a frog entity.
     * @param x The x coordinate to spawn in.
     * @param y The y coordinate to spawn in.
     */
    public Frog(int x, int y){
        this.crossableTiles = new String[]{"Path", "Button"};
        currentX = x;
        currentY = y;
        super.spawnIn(x,y);
        pathfindingGrid = new int[Main.getGridWidth()][Main.getGridHeight()];

        //set player val to max distance needed to cover the whole grid
        pathfinderPlayerVal = Math.max(Main.getGridWidth(), Main.getGridHeight());
    }

    /**
     * Checks if player can be reached in an adjacent tile.
     * @return The x and y coordinates to move to as an int array.
     */
    private int[] simpleSideCheck() {
        int playerX = Main.getPlayerX();
        int playerY = Main.getPlayerY();

        //check north, south, east, west
        if (playerX == currentX && playerY == currentY - 1) {
            return new int[] {currentX, (currentY - 1)};
        }
        else if (playerX == currentX && playerY == currentY + 1)
        {
            return new int[] {currentX, (currentY + 1)};
        }
        else if (playerX == currentX + 1 && playerY == currentY)
        {
            return new int[] {currentX + 1, currentY};
        }
        else if (playerX == currentX - 1 && playerY == currentY)
        {
            return new int[] {currentX - 1, currentY};
        }

        return null;
    }

    /**
     * Updates the pathfinding grid with up to date values.
     * Generates grid of values where would be best for the frog to exist in and
     * where it cannot go.
     */
    private void calculateGrid()
    {
        int playerX = Main.getPlayerX();
        int playerY = Main.getPlayerY();

        int[][] gridArray = new int[Main.getGridWidth()][Main.getGridHeight()];

        //set impassable tiles to -1;
        for (int i = 0; i < Main.getGridWidth(); i++)
        {
            for (int j = 0; j < Main.getGridHeight(); j++)
            {
                if (!validMovementSpace(i, j))
                {
                    gridArray[i][j] = PATHFINDER_UNWALKABLE_VAL;
                }
                else
                {
                    gridArray[i][j] = 0;
                }
            }
        }

        //set player pos to pathfinVAl
        gridArray[playerX][playerY] = pathfinderPlayerVal;

        //iterate blur till reach edges
        for (int x = 0; x < pathfinderPlayerVal; x++)
        {
            //check sides of each pos to do the blur
            for (int i = 0; i < Main.getGridWidth(); i++)
            {
                for (int j = 0; j < Main.getGridHeight(); j++)
                {
                    if (gridArray[i][j] != -1)
                    {
                        //check north, south, east, west
                        int valueToNorth = -1;
                        int valueToSouth = -1;
                        int valueToEast = -1;
                        int valueToWest = -1;

                        if (j - 1 >= 0)
                        {
                            valueToNorth = gridArray[i][j - 1];
                        }
                        if (j + 1 < Main.getGridHeight())
                        {
                            valueToSouth = gridArray[i][j + 1];
                        }
                        if (i + 1 < Main.getGridWidth())
                        {
                            valueToEast = gridArray[i + 1][j];
                        }
                        if (i - 1 >= 0)
                        {
                            valueToWest = gridArray[i - 1][j];
                        }

                        //find max adjacent value and reduce it
                        int maxValue = Math.max(valueToNorth, Math.max(valueToSouth,
                                Math.max(valueToEast, valueToWest)));
                        if(maxValue > 0 && maxValue > gridArray[i][j])
                        {
                            gridArray[i][j] = maxValue - 1;
                        }
                    }
                }
            }
        }
        this.pathfindingGrid = gridArray;
    }

    /**
     * Finds the next tile to move to along the shortest path to the player.
     * @return The x and y coordinates to move to as an int array.
     */
    private int[] getMoveInPath() {
        //check sides on each side to find where to go
        int i = currentX;
        int j = currentY;
        //check north, south, east, west
        int valueToNorth = -1;
        int valueToSouth = -1;
        int valueToEast = -1;
        int valueToWest = -1;

        if (j - 1 >= 0 && validMovementSpace(i,j - 1))
        {
            valueToNorth = pathfindingGrid[i][j - 1];
        }
        if (j + 1 < Main.getGridHeight() && validMovementSpace(i,j + 1))
        {
            valueToSouth = pathfindingGrid[i][j + 1];
        }
        if (i + 1 < Main.getGridWidth() && validMovementSpace(i + 1 ,j))
        {
            valueToEast = pathfindingGrid[i + 1][j];
        }
        if (i - 1 >= 0 && validMovementSpace(i - 1,j))
        {
            valueToWest = pathfindingGrid[i - 1][j];
        }

        //find max adjacent value and set to move to that space,
        //if it is part of the path (!=0)
        int maxValue = Math.max(valueToNorth, Math.max(valueToSouth,
                Math.max(valueToEast, valueToWest)));

        if (maxValue > 0)
        {
            if (maxValue == valueToNorth) {
                return new int[] {i,j-1};
            }
            else if (maxValue == valueToSouth)
            {
                return new int[] {i,j+1};
            }
            else if (maxValue == valueToWest)
            {
                return new int[] {i-1,j};
            }
            else if (maxValue == valueToEast)
            {
                return new int[] {i+1,j};
            }
        }

        return null;
    }

    /**
     * Chooses a random valid adjacent tile to move to.
     * For use in move() when shortest path move not available.
     * @return The x and y coordinates to move to as an int array.
     */
    private int[] calculateRandomMove() {
        //move randomly in available space if player inaccessible
        ArrayList<Direction> directionsMovable = new ArrayList<>();
        if (currentY - 1 >= 0 && validMovementSpace(currentX, currentY-1)) {
            directionsMovable.add(Direction.NORTH);
        }
        if (currentY + 1 < Main.getGridHeight() && validMovementSpace(currentX, currentY+1)) {
            directionsMovable.add(Direction.SOUTH);
        }
        if (currentX - 1 >= 0 && validMovementSpace(currentX-1, currentY)) {
            directionsMovable.add(Direction.WEST);
        }
        if (currentY + 1 < Main.getGridWidth() && validMovementSpace(currentX+1, currentY)) {
            directionsMovable.add(Direction.EAST);
        }

        Random random = new Random();
        if (directionsMovable.size() > 0)
        {
            int randomVal = random.nextInt(directionsMovable.size());
            Direction chosenDir = directionsMovable.get(randomVal);

            switch (chosenDir)
            {
                case NORTH:
                    return new int[]{currentX, currentY - 1};
                case SOUTH:
                    return new int[]{currentX, currentY + 1};
                case EAST:
                    return new int[]{currentX + 1, currentY};
                case WEST:
                    return new int[]{currentX - 1, currentY};
            }
        }
        return null;
    }

    /**
     * Execute 1 tile movement of the enemy.
     * Fetches and executes the best valid move to attempt to reach the player.
     */
    @Override
    protected void move()
    {
        //move immediately to player if next to it, otherwise try moving by the grid path
        if (simpleSideCheck() != null) {
            int potentialX = simpleSideCheck()[0];
            int potentialY = simpleSideCheck()[1];
            Main.setValueInActorLayer(currentX, currentY, null);
            Main.setValueInActorLayer(potentialX, potentialY, this);
            currentX = potentialX;
            currentY = potentialY;
        }
        else
        {
            calculateGrid();
            if (getMoveInPath() != null)
            {
                int potentialX = getMoveInPath()[0];
                int potentialY = getMoveInPath()[1];
                Main.setValueInActorLayer(currentX, currentY, null);
                Main.setValueInActorLayer(potentialX, potentialY, this);
                currentX = potentialX;
                currentY = potentialY;
            }
            else
            {
                int[] potentialXY = calculateRandomMove();
                if (potentialXY != null)
                {
                    int potentialX = potentialXY[0];
                    int potentialY = potentialXY[1];
                    Main.setValueInActorLayer(currentX, currentY, null);
                    Main.setValueInActorLayer(potentialX, potentialY, this);
                    currentX = potentialX;
                    currentY = potentialY;
                }
            }
        }
    }
}
