import javafx.scene.image.Image;

/**
 * Locked door/tile block that is impassable unless the player has the correct key.
 * @author William Allen, Owain Jones
 * @version 1
 */
public class LockedTile extends TileObjects {
    private Image sprite = new Image("baseTextures/gold_lock.png");
    private int colour;

    /**
     * Generates a locked door object of the corresponding colour.
     * @param colour 1-4, A numerical representation of the colour/type of the door.
     */
    public LockedTile(int colour)
    {
        this.colour = colour;
        switch(colour)
        {
            case(1):
                sprite = new Image("baseTextures/copper_lock.png");
                break;
            case(2):
                sprite = new Image("baseTextures/gold_lock.png");
                break;
            case(3):
                sprite = new Image("baseTextures/diamond_lock.png");
                break;
            case(4):
                sprite = new Image("baseTextures/emerald_lock.png");
                break;
        }
    }
    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Fetches the colour of the door.
     * @return 1-4, A numerical representation of the colour/type of the door.
     */
    public int getColour() {return colour;}
}