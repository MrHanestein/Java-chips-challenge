import javafx.scene.image.Image;
/**
 * Lever/button object that controls the state of the relevant trap(s).
 *
 * @author David Anthony, Owain Jones.
 * @version 1
 */
public class Lever extends TileObjects {

    private Image spriteOn = new Image("baseTextures/lever_down.png");
    private Image spriteOff = new Image("baseTextures/lever_up.png");
    private Image sprite = spriteOff;
    private int signal;

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }

    /**
     * Constructs a lever.
     * @param signal The signal id for the lever/trap link.
     */
    public Lever(int signal)
    {
        this.signal = signal;
    }

    /**
     * Changes the state of the lever.
     * @param isOn true/false Whether the lever is now presssed or not.
     */
    public void alterState(boolean isOn)
    {
        if (isOn)
        {
            sprite = spriteOn;
        }
        else
        {
            sprite = spriteOff;
        }
    }

    /**
     * Gets the signal (button-trap link) id number.
     * @return The signal id value
     */
    public int getSignal()
    {
        return signal;
    }
}