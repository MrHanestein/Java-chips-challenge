package MainSubClasses;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileWriter;

/**
 * File reader class that handles getting data from the level files, and writing to them.
 * @author Owain Jones
 * @version 2
 */
public class FileReader {

    /**
     * Loads data in the file at the given path.
     * @param path The path of the file to be loaded.
     * @return The data in the file.
     */
    public static String[] loadFile(String path)
    {
        String[] file = new String[512];
        try {
            File myObj = new File(path);
            Scanner myReader = new Scanner(myObj);
            int i = 0;
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                file[i] = data;
                i++;
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("File Reader Broke, not Good.");
            e.printStackTrace();
        }

        return file;
    }

    /**
     * Extracts the basic data about the level and the player position.
     * @param file All the loaded data of the level file.
     * @return The basic level data.
     */
    public static int[] getBaseLevel(String[] file)
    {
        int[] returnData = new int[6];
        String[] splitData = file[0].split("#");
        returnData[0] = Integer.parseInt(splitData[0]);
        returnData[1] = Integer.parseInt(splitData[1]);
        returnData[2] = Integer.parseInt(splitData[2]);
        returnData[3] = Integer.parseInt(splitData[3]);
        returnData[4] = Integer.parseInt(splitData[4]);
        returnData[5] = Integer.parseInt(splitData[5]);

        return returnData;
    }

    /**
     * Extracts the highscore data for the level.
     * @param file All the loaded data of the level file.
     * @return The extracted high score data.
     */
    public static String[] getHighscore(String[] file)
    {
        String[] returnData = new String[10];
        for (int i = 0; i < 10; i++) {
            returnData[i] = file[2 + i];
            System.out.println(file[2 + i]);
        }
        return returnData;
    }

    /**
     * Extracts the tile layout information for the level.
     * @param file All the loaded data of the level file.
     * @param height The height of the grid that will be used.
     * @return The extracted tile data.
     */
    public static String[] getTileLayer(String[] file, int height)
    {
        String[] returnData = new String[height];
        for (int i = 0; i < height; i++) {
            returnData[i] = file[13 + i];
        }
        return returnData;
    }

    /**
     * Extracts the items and their layout information for the level.
     * @param file All the loaded data of the level file.
     * @param height The height of the grid that will be used.
     * @return The extracted item data.
     */
    public static String[] getItemLayer(String[] file, int height)
    {
        String[] returnData = new String[height];
        for (int i = 0; i < height; i++) {
            returnData[i] = file[13 + 1 + height + i];
        }
        return returnData;
    }

    /**
     * Extracts the actors and their layout information for the level.
     * @param file All the loaded data of the level file.
     * @param height The height of the grid that will be used.
     * @return The extracted actor data.
     */
    public static String[] getActorLayer(String[] file, int height)
    {
        String[] returnData = new String[height];
        for (int i = 0; i < height; i++) {
            returnData[i] = file[13 + 2 + height*2 + i];
        }
        return returnData;
    }

    /**
     * Extracts the players inventory state.
     * @param file All the loaded data of the level file.
     * @param height The height of the grid that will be used.
     * @return The extracted inventory data.
     */
    public static int[] getInventory(String[] file, int height)
    {
        int[] returnData = new int[10];

        String[] splitData = file[13 + 3 + height*3].split("#");

        for (int i = 0; i < returnData.length; i++) {
            returnData[i] = Integer.parseInt(splitData[i]);
        }
        return returnData;
    }

    /**
     * Turns base data about the level into the writeable file format.
     * @param gridX The width of the game grid.
     * @param gridY The height of the game grid.
     * @param texturePack The texture pack used.
     * @param time The time for the player to finish the level in.
     * @param pX The player x coordinate.
     * @param pY The player y coordinate.
     * @return The string representation of the basic level data.
     */
    public static String turnBaseData (int gridX, int gridY, int texturePack, int time, int pX, int pY) {
        return Integer.toString(gridX) + "#" +Integer.toString(gridY) + "#" +Integer.toString(texturePack) + "#" +
                Integer.toString(time) + "#" +Integer.toString(pX) + "#" +Integer.toString(pY);
    }

    /**
     * Method to save level information to the given file.
     * @param file All the loaded data of the level file.
     * @param path The path of the file to be loaded.
     */
    public static void saveFile(String[] file, String path)  {
        FileWriter writer = null;
        try {
            writer = new FileWriter(path);


            for (String s : file)
            {
                writer.write(s + "\n");
            }
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

}
