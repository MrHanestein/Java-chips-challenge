package MainSubClasses;

/**
 * Collection of methods to assist in various calculations in the Main method.
 * @author Owain Jones, Jawad Zaman
 * @version 1
 */
public class MathHelper {

    public static int table[] = new int[] {
            0, 27, 11,18 ,37, 41, 35, 23, 22, 3, 2, 53, 46, 56, 6, 44, 50, 58, 52, 14, 60, 63, 26, 5, 21, 15, 16, 36, 59, 9,
            45, 40, 51, 42, 54, 20, 55, 8, 32, 19, 1, 57, 64, 25, 43, 34, 31, 39, 33, 24, 30, 13, 29, 61, 7, 47, 62, 4, 28, 17, 12, 48, 38, 10, 49};

    private static int index = 0;

    /**
     * Converts momentum to a degree angle.
     * @param xDir Horizontal momentum.
     * @param yDir Vertical momentum.
     * @return The direction in degrees.
     */
    public static int convertToAngle(int xDir, int yDir)
    {
        int dir;

        //Does NOT support Diagonal movement.
        if (xDir != 0) {
            dir = 90 * (xDir);
        }
        else {
            dir = 90 + 90 * (yDir);
        }
        return dir;
    }

    /**
     * Converts an angle in degrees to momentum.
     * @param dir The angle direction in degrees.
     * @return Horizontal and Vertical momentum as an int array.
     */
    public static int[] convertFromAngle(int dir)
    {
        int[] newCords = new int[2];
        int momentumX = 0;
        int momentumY = 0;

        switch (dir) {
            case (0), (360) ->  momentumY = -1;
            case (90) ->  momentumX = 1;
            case (180) ->  momentumY = 1;
            case (270) ->  momentumX = -1;
        }

        newCords[0] = momentumX;
        newCords[1] = momentumY;

        return newCords;

    }

    /**
     * Calculates the score achieved.
     * @param time The time remaining for the player.
     * @param chips The number of chips/chip block unlocked.
     * @param coins The value of coins collected.
     * @return The player's score
     */
    public static int calculateScore(int time, int chips, int coins){
        return time * 10 + chips * 5 + coins * 2;
    }

    /**
     * Converts ticks to seconds
     * @param ticks The number of ticks.
     * @param tickRate The speed of ticks in the game.
     * @return The number of equivalent seconds.
     */
    public static int ticksToSeconds(int ticks, int tickRate){
        return ticks/tickRate;
    }

    /**
     * Converts ticks to minutes.
     * @param ticks The number of ticks.
     * @param tickRate The speed of ticks in the game.
     * @return The number of equivalent minutes.
     */
    public static int tickToMinutes(int ticks, int tickRate){
        return ticksToSeconds(ticks, tickRate)/60;
    }

    /**
     * Converts ticks to a displayable minute:second format.
     * @param ticks The number of ticks.
     * @param tickrate The speed of ticks in the game.
     * @return The tick time in minutes and seconds.
     */
    public static String tickToTime(int ticks, int tickrate) {
        int minutes = tickToMinutes(ticks, tickrate);
        int second = ticksToSeconds(ticks, tickrate) % 60;

        if (second < 10)
        {
            return String.valueOf(minutes) + ":0" + second;
        }

        return String.valueOf(minutes) + ":" + second;
    }

    /**
     * Generates a random number in the given range.
     * @param min The lower bound to generate between.
     * @param max The upper bound to generate between.
     * @return The random int value.
     */
    public static int returnRandom(int min, int max) {
        boolean hasValue = false;
        int returnVal = 0;
        while (!hasValue) {
            int num = table[index];

            if (min <= num && num <= max)
            {
                returnVal = num;
                hasValue = true;
            }
            index++;

            if (index > table.length - 1)
            {
                index = 0;
            }
        }

        return returnVal;
    }
}
