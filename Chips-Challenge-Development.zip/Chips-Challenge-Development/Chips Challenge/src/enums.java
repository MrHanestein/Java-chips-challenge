/*enum Tiles {
    PATH,
    DIRT,
    WALL,
    EXIT,
    WATER,
    ICE,
}*/

/**
 * Enumerated types used throughout the package
 * @author Emilija Baraskina, Owain Jones
 * @version 2
 */

/**
 * Types of ice block situations
 */
enum IceChecks {
    WALL,
    FROMBASE,
    FROMNEXT,
}

/**
 * The 4 cardinal directions
 */
enum Direction {
    NORTH,
    SOUTH,
    EAST,
    WEST
}


