import javafx.scene.image.Image;

/**
 * Curved ice tile, that works like Ice but makes the player turn 90 degress in
 * one direction (implemented in Main).
 * @author Owain Jones
 * @version 1
 */
public class CurvedIce extends TileObjects {
    //The 'open sections' of ice are the rotated angle and the angle + 90.
    private int rotation;
    private Image sprite = new Image("baseTextures/ice_curved_ul.png");

    /**
     * Constructs a curved ice tile with the set rotation.
     * @param rotation The angle of the exit of the tile relative to entrance (0/90/180/270).
     */
    public CurvedIce(int rotation)
    {
        this.rotation = rotation;
        switch (this.rotation) {
            case(0):
                this.sprite = new Image("baseTextures/ice_curved_ur.png");
                break;
            case(90):
                this.sprite = new Image("baseTextures/ice_curved_dr.png");
                break;
            case(180):
                this.sprite = new Image("baseTextures/ice_curved_dl.png");
                break;
            case(270):
                this.sprite = new Image("baseTextures/ice_curved_ul.png");
                break;
        }
    }

    /**
     * The angle of the exit of the tile relative to entrance in degrees.
     * @return The angle of the exit of the tile relative to entrance (0/90/180/270).
     */
    public int getRotation()
    {
        return rotation;
    }

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}