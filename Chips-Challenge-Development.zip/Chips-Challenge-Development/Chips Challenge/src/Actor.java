import javafx.scene.image.Image;

/**
 * Superclass/collection of all actor entities (those that can move or be moved by the
 * player).
 * @author Owain Jones
 * @version 1
 */
public class Actor
{
    private Image sprite = new Image("baseTextures/spider.gif");

    /**
     * Fetch the currently set sprite image of the entity.
     * @return The current sprite.
     */
    public Image getSprite()
    {
        return sprite;
    }

    // hello 


    /**
     * Set the specified image as the current sprite.
     * @param sprite The image to be set as the sprite.
     */
    public void setSprite(Image sprite)
    {
        this.sprite = sprite;
    }
}
